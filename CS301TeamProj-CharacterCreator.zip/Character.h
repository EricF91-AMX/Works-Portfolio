/*
* Character.h
*
*  Created on: Oct 5, 2019
*      Author: Eric J Fong
*/

#ifndef CHARACTER_H_
#define CHARACTER_H_
#include <string>
using namespace std;

class Character {

public:
	friend class SortedList;
	Character();
	virtual ~Character();

	//mutator methods
	void newAttr();
	void newAttr(int, string);
	void newAttr(string, string);
	void modAttr(string, string);
	void modAttr(int, string);
	void deleteAttr(string);
	void deleteAttr(int, bool);
	void printAttr();

	//accessor methods
	const int getIntAttr(string);
	const string getStrAttr(string);
	const int getIntAttrIndex();
	const int getStrAttrIndex();

	//additional methods
	Character* setNextPtr(Character *);
	void randomizeAttr(string, int);

private:
	int amtIntAttrs;
	int amtStrAttrs;

	int* intAttrs;			//dyn. arr. storing integer attribute values (i.e. '50' for max HP, '32' for dexterity, etc.)
	string* strAttrs;		//dyn. arr. storing string attribute values (i.e. 'elf' for race, 'priest' for job class, etc.)
	string* intAttrNames;	//dyn. arr. storing names of integer attributes (i.e. 'HP', 'Intelligence', 'weight', etc.)
	string* strAttrNames;	//dyn. arr. storing names of string attributes (i.e. 'race', 'server', 'name', etc.)
	Character *next;

	void init();
	const int comparedTo(Character*);
	int getAttrIndex(string, bool);

};

#endif /* CHARACTER_H_ */
