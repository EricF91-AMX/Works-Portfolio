#include "stdafx.h"
/*
* SortedList.cpp
*
*  Created on: Oct 5, 2019
*      Author: Eric J Fong
*/
#include "stdafx.h"
#include "SortedList.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;
 
SortedList::SortedList() {
	// TODO Auto-generated constructor stub
	characterList = nullptr; // head of list
	current = nullptr;
}

Character* SortedList::getCharacter(string str) {
	Character *temp = characterList; // set temp to start of list
	while (temp) {// while temp isn't nullptr parse
		if (*(temp->strAttrs + 0) == str) {// if the attribute of strAttrs[0](name of character) 
			return &(*temp);// return that node by reference
		}
		// else continue parsing
		temp = temp->next;
	}

	cout << "Character doesn't exist in list " ;

	return nullptr; // return newCharacter itself
}

void SortedList::saveList(fstream &out) {
	Character *temp = characterList;

	while (temp) {
		// save string attributes in following format: Name=username	Race=Elf
		for (int i = 0; i < temp->getStrAttrIndex(); ++i) {
			out << *(temp->strAttrNames + i) << "=" << *(temp->strAttrs + i) << '\t';
		}
		//save integer attributes in following format: Hp=99	Dexterity=44
		for (int i = 0; i < temp->getIntAttrIndex(); ++i) {
			out << *(temp->intAttrNames + i) << "=" << *(temp->intAttrs + i) << '\t';
		}
		out << endl;
		temp = temp->next;
	}
}

void SortedList::deleteCharacter(string str) {

	if (!characterList) {
		cout << " === list is empty, cannot delete any characters === " << endl;
		return;
	}
	else {
		Character *Loc = characterList; // set Loc to head of list
		Character *preLoc = characterList; // set preLoc to head

		while (Loc) { // while ptr doesn't reach end of list look for matching name to str
			if (*(Loc->strAttrs + 0) == str) { // if character is found
				cout << "Will now delete " << str << endl;

				if (characterList->comparedTo(Loc) == 2) { // this would indicate that we need to delete the head
					characterList = characterList->next; // set head to begin at next node
				}
				else if (current->comparedTo(Loc) == 2) { // would indicate that we need to delete tail
					preLoc->next = nullptr; // set end of list to nullptr
					current = preLoc; // reset current(tail) to second to last node
				}
				else {
					preLoc->next = Loc->next; // connect list by skipping the Loc node
				}

				preLoc = nullptr;
				delete preLoc;		//delete both temporary pointers
				delete Loc;			// and the node that was to be deleted
				length--; // decrease the length of list by 1
				return; // node has been deleted exit
			}// if character found

			if (!Loc->next) { // check if Loc reaches end of list without finding the character
				cout << "=== Character doesn't exist ===" << endl;
				return;
			}

			preLoc = Loc;
			Loc = Loc->next;
		}// while loop
	}// else
} // delete function

void SortedList::insert(Character *newCharacter) {
	
	if (!characterList) {// check if list is currently empty;
		characterList = newCharacter; // if list is empty then point head to temp
		current = newCharacter;
		current->next = nullptr;
		length++; // increase length
	}
	else { // check where in the list to insert
		Character *loc = characterList;// set temp to head of list used for node to connect: newCharacter->loc
		Character *preLoc = characterList;// set preLoc to head as well used for node to connect: preLoc->newCharacter
		//check if temp should be the new head
		if (newCharacter->comparedTo(characterList) == 0) {// checks to see if head needs to be replaced
			newCharacter->next = characterList;
			characterList = newCharacter;

		}// else check if need to append instead
		else if (current->comparedTo(newCharacter) == 0) {
			current->next = newCharacter;
			current = newCharacter;
			current->next = nullptr;
		}// otherwise parse through list
		else {// parse through list if current location loc is where to break off for insertion
			while (loc) {// loop to parse until end of loop
				if (newCharacter->comparedTo(loc) == 0) {
					preLoc->next = newCharacter;
					newCharacter->next = loc;
					break;
				}
				else if (newCharacter->comparedTo(loc) == 2) {
					cout << "=== Character user name already in list ===" << endl;
					return;
				}
				// if the above does not execute then move on to next node in list
				preLoc = loc; // parse preloc one node up to loc
				loc = loc->next; // parse loc one node up
			}// while loop to parse through list
		}// else

		length++; // increase length
	}// else to find insertion
}// insert function

void SortedList::printList() {
	if (!characterList) {
		cout << "list is empty " << endl;
		return;
	}
	cout << setfill('-') << setw(100) << "-" << endl;
	cout << setfill(' ') <<"|" << setw(10) << "Username" << setw(10) << "|" << setw(45) << "Attributes" << setw(35) << "|" << endl;
	cout << setfill('-') << setw(100) << "-" << endl;

	Character *ptr = characterList; // set ptr to head of list
	int index = 0;
	while (ptr) {

		//display attribute names
		cout << "|" << setfill(' ') << setw(20) << "|";
		if (ptr->getStrAttrIndex() > 0) {
			// output the attributes of the string attributes starting at 1 since 0 is name
			for (int i = 1; i < ptr->getStrAttrIndex(); ++i) {
				cout << setw(7) << *(ptr->strAttrNames + i) << setw(8) << "|";
			}
			// output the attributes of the integer attributes starting at 0
			for (int i = 0; i < ptr->getIntAttrIndex(); ++i) {
				cout << setw(7) << *(ptr->intAttrNames + i) << setw(8) << "|";
			}
		}// if attribute > 0
		//display attributes names

		//display username
		cout <<"\n|" << setfill(' ') << setw(20) << "|" << setfill('-') << setw(80) << "|" << endl;
		cout << "|" << setfill(' ') << setw(10) << *(ptr->strAttrs + 0) << setw(10) << "|";
		// for loop displaying brackets of attributes
		for (int i = 0; i < (ptr->getIntAttrIndex() + ptr->getStrAttrIndex()) - 1; ++i)
			cout << setw(15) << "|";
		cout << endl;
		// display username

		//display atrribute values///////
		cout << "|" << setw(20) << "|";
		if (ptr->getStrAttrIndex() > 0) {
			// output the attributes of the string attributes starting at 1 since 0 is name
			for (int i = 1; i < ptr->getStrAttrIndex(); ++i) {
				int x = 8;
				if ((*(ptr->strAttrs + i)).length() > 7)
					x = 8 - ((*(ptr->strAttrs + i)).length() - 7);
				cout << setw(7) << *(ptr->strAttrs + i) << setw(x) << "|";
			}
			// output the attributes of the integer attributes starting at 0
			for (int i = 0; i < ptr->getIntAttrIndex(); ++i) {
				cout << setw(7) << *(ptr->intAttrs + i) << setw(8) << "|";
			}
		}// if attribute > 0
		//display attribute values////////

		cout << "\n" << setfill('-') << setw(101) << "|" << endl;
		index++;
		ptr = ptr->next;
	}
}

string SortedList::printNames() {
	
	string returner = " ";
	if (!characterList) {
		cout << "There are no characters\n";
		return returner;
	}
	else {
		string *name = new string[this->length];
		Character *ptr = characterList;
		cout << "Current Characters \n";
		int i = 0;
		while (ptr) {
			cout << i << " - " << *(ptr->strAttrs + 0) << endl;
			*(name + i) = *(ptr->strAttrs + 0);
			ptr = ptr->next;
			i++;
		}
		cout << "Enter character to mod => ";
		cin >> i;
		if (i > this->length || i < 0) return " ";
		returner = *(name + i);
		name = nullptr;
		delete name;
		return returner;
	}
}

const int SortedList::getLength() {
	return this->length;
}

SortedList::~SortedList() {
	// TODO Auto-generated destructor stub
}