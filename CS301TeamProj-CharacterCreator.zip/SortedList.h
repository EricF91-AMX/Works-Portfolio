/*
* SortedList.h
*
*      Author: Eric Fong [ue5533], Emmanuel Gonzalez [NET ID]
*/

#ifndef SORTEDLIST_H_
#define SORTEDLIST_H_
#include "Character.h"

class SortedList: public Character{
public:
	SortedList();
	virtual ~SortedList();

	//
	void insert(Character*);
	void deleteCharacter(string);
	void saveList(fstream &);
	void printList();

	Character * getCharacter(string);
	string printNames();
	const int getLength();

private:
	int length;
	int max_size;

	Character* characterList;
	Character* current;
};

#endif /* SORTEDLIST_H_ */
