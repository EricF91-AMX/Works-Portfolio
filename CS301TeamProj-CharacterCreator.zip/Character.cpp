/*
* Character.cpp
*      Author: Eric Fong [ue5533], Emmanuel Gonzalez [], Darren Tze[]
*/
#include "stdafx.h"
#include "Character.h"
#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <time.h>
using namespace std;


//declare and initialize constants
const int DEFAULT = 4;

Character::Character() {
	init();
} //default constructor

Character::~Character() {
	// TODO Auto-generated destructor stub
} //destructor

  //helper methods
  //initializer method
void Character::init() {
	amtIntAttrs = 0;
	amtStrAttrs = 0;
	intAttrs = new int[DEFAULT];
	intAttrNames = new string[DEFAULT];
	strAttrNames = new string[DEFAULT];
	/* strAttrNames[1=names, 2=race, 3 = ?, 4= ?] */
	strAttrs = new string[DEFAULT]; // values of ^ 
									/* strAttrs[1 = nameofcharacter, 2 = elf(value of race), 3 =?]*/

	next = nullptr;
} //init()

Character * Character::setNextPtr(Character *current)
{
	current = current->next;
	return current;
}

//comparison method used for sorting
const int Character::comparedTo(Character* Loc) { // compares to location of insertion

	if (*(this->strAttrs + 0) < *(Loc->strAttrs + 0)) // compare the names attribute in strAttrs index 1
		return 0;// if the current location is greater return 0: meaning need to replace this location Loc
	else if (*(this->strAttrs + 0) == *(Loc->strAttrs + 0))
		return 2; // this indicates that the strings are equal( same name )
	else
		return 1;// 1 indicates to keep parsing through the list

} //comparedTo(Character)

  //method to return the index of the attribute with a name matching the argument
int Character::getAttrIndex(string attrName, bool isInt) {
	//declare and initialize variables
	int retIndex = 0;

	//loop through intAttrNames or strAttrNames to find the index of the attr with the matching name
	if (isInt)
		while (retIndex < amtIntAttrs) {
			if (!attrName.compare(*(intAttrNames + retIndex))) {
				return retIndex;
			} //if
			retIndex++;
		} //while
	else {
		while (retIndex < amtStrAttrs) {
			if (!attrName.compare(*(strAttrNames + retIndex))) {
				return retIndex;
			} //if
			retIndex++;
		} //while
	}
	  //attrName not found case
	string str = "Attribute not found";
	throw str;
	return -1;
} //getAttrIndex(string)

void Character::printAttr() {
	cout << "Current attributes for: " << *(strAttrs + 0) << endl;
	cout << setfill(' ');
	for (int i = 0; i < amtIntAttrs; ++i) {
		cout << setw(20) << *(intAttrNames + i) << endl;
	}
	for (int j = 1; j < amtStrAttrs; ++j) {
		cout << setw(20) << *(strAttrNames + j) << endl;
	}
}


  //mutator methods
void Character::newAttr() {
	string attrName, attrVal;
	cin.ignore(1000, 10);
	cout << "Enter the name of the Attribute ==> ";
	getline(cin, attrName);
	cin.ignore(1000, 10);
	cout << "Enter the value of the attribute ==> ";
	getline(cin, attrVal);
	cin.ignore(1000, 10);

	if (isdigit(attrVal[0]) && isdigit(attrVal[attrVal.length() - 1])) {
		int x = stoi(attrVal);
		newAttr(x, attrName);
	}
	else
		newAttr(attrName, attrVal);
}
  //creates a new integer attribute and adds it to the intAttrs array
void Character::newAttr(int value, string attrName) {
	for (int i = 0; i < amtIntAttrs; ++i) {// checks to see if attribute is already a part of character
		if (*(intAttrNames + i) == attrName) {// comparison to pre-existing attributes
			cout << "That attribute already exists\n ";
			return;	// returns if attribute is found 
		}
	}

	*(intAttrs + amtIntAttrs) = value;
	*(intAttrNames + amtIntAttrs) = attrName;

	amtIntAttrs++;
} //newAttr(int, string)

  //creates a new string attribute and adds it to the strAttrs array
void Character::newAttr(string attrName, string attribute) {
	for (int i = 0; i < amtStrAttrs; ++i) {// checks to see if attribute is already a part of character
		if (*(strAttrNames + i) == attrName) {// comparison to pre-existing attributes
			cout << "That attribute already exists\n ";
			return;	// returns if attribute is found 
		}
	}


	*(strAttrNames + amtStrAttrs) = attrName;
	*(strAttrs + amtStrAttrs) = attribute;

	amtStrAttrs++;
} //newAttr(string, string)

void Character::deleteAttr(string attrName) {
	try {
		// look for the index of the attribute at the integer value attributes
		int indexDel = getAttrIndex(attrName, 1);// search through int list
		deleteAttr(indexDel, 1);// delete int attribute
	}
	catch (string e) {
		try {
				int indexDel = getAttrIndex(attrName, 0);// search through string list
				deleteAttr(indexDel, 0);
		}
		catch (string e) {
			throw e;
		}
	}
}

void Character::deleteAttr(int index, bool isInt) {
	int i = index;
	
	if (isInt) {// delete integer attribute
		cout << "Will delete: " << *(intAttrNames + i) << "=" << *(intAttrs + i) << endl;
		while (i < amtIntAttrs-1) {
			*(intAttrNames + i) = *(intAttrNames + i + 1);
			*(intAttrs + i) = *(intAttrs + i + 1);
			i++;
		}
		amtIntAttrs--;
		return;
	}
	while (i < amtStrAttrs - 1) {
		cout << "Will delete: " << *(intAttrNames + i) << "=" << *(intAttrs + i) << endl;

		*(strAttrNames + i) = *(strAttrNames + i + 1);
		*(strAttrs + i) = *(strAttrs + i + 1);
		i++;
	}
	amtStrAttrs--;

}
  //overwrites the value of a designated integer attribute
void Character::modAttr(int value, string attrName) {
	try {
		intAttrs[getAttrIndex(attrName, 1)] = value;
	}
	catch (exception e) {
		throw e;
	}

} //modAttr(int, string)

  //overwrites the value of a designated string attribute
void Character::modAttr(string value, string attrName) {
	try {
		strAttrs[getAttrIndex(attrName, 0)] = value;
	}
	catch (exception e) {
		throw e;
	}
} //modAttr(string, string)



  //accessor methods
  //returns the value of the integer attribute whose name matches the string argument
const int Character::getIntAttr(string attrName) {
	return intAttrs[getAttrIndex(attrName, 1)];
} //getIntAttr(string)

  //returns the value of the string attribute whose name matches the string argument
const string Character::getStrAttr(string attrName) {
	return strAttrs[getAttrIndex(attrName, 0)];
} //getStrAttr(string)

const int Character::getIntAttrIndex() {
	return amtIntAttrs; // return the size of the amtIntAttrs
						// the size of the array of integer attributes intAttrs
}

const int Character::getStrAttrIndex() {
	return amtStrAttrs; // return the size of the amtStrAttrs
						// the size of the array of string attributes strAttrs
}



// Additional methods

//method to assign a random value to the integer attribute whose name is the string argument
void Character::randomizeAttr(string attrName, int limit) {
	//declare and initialize variables
	int index = getAttrIndex(attrName, 1);

	//no matching attr name case
	if (index == -1) {
		cout << "no matching attribute of name " << attrName << " was found." << endl;
		return;
	} //if

	  //seed RNG
	srand(time(NULL));

	//assign random int value to the targeted intAttr
	intAttrs[index] = rand() % limit;

	return;
} //randomizeAttr(string, int)
