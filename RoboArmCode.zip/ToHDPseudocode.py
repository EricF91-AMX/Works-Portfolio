# Filename: ToHDPseudocode.py
# Authors: Eric Fong, Christian Alcalde
# Description: pseudocode for CMPE344 Group 8's Tower of Hanoi Demonstrator robot

# hardcode dimensions, distances, number of disks for ToHD
# take start signal from start button
# execute ToH algorithm
# move claw to position of first tower



#=====Python code for hardcoded initial conditions=====

#declare and initialize constants
DISKAMT = 3

#import libraries and files
import Adafruit_BBIO.GPIO as GPIO
import time

# define functions
# methods to plan move order
def ToHMoves(moveOrder):
	ToHAlgorithm(moveOrder,DISKAMT,1,2,3)
	return moveOrder;

def ToHAlgorithm(moveOrder,N,beg,other,tgt)
	if(N==1):
		toAppend = [beg,(tgt+3)]
		moveOrder.extend(toAppend)
	else:
		ToHAlgorithm(moveOrder,N-1,beg,tgt,other)
		ToHAlgorithm(moveOrder,1,beg,other,tgt)
		ToHAlgorithm(moveOrder,N-1,other,beg,tgt)
	return



# method to loop through the move order list and physically execute moves
def ToHWork(moveOrder):
	s = pythonSwitch()
	for index in range(len(moveOrder)):
		if (index%2)==1:
			continue
		s.switch(moveOrder[index]);		#6 possible moves for 3 stack ToH puzzle
	return;

#method to operate claw and arm-pitch motors to pick up or drop a piece
def liftDrop(moveType):
	if moveType==1:
			GPIO.output("P9_12",GPIO.HIGH)	#open claw
			time.sleep(0.1)
			GPIO.output("P9_12",GPIO.LOW)
			time.sleep(0.5)
	GPIO.output("P9_26",GPIO.HIGH)	#lower arm into position
	time.sleep(0.95)
	GPIO.output("P9_26",GPIO.LOW)
	time.sleep(0.5)
	if moveType==0:
		GPIO.output("P9_13",GPIO.HIGH)	#close claw
		time.sleep(0.2)
		GPIO.output("P9_13",GPIO.LOW)
		time.sleep(0.5)
	GPIO.output("P9_26",GPIO.HIGH)	#raise arm
	time.sleep(1.15)
	GPIO.output("P9_26",GPIO.LOW)
	time.sleep(0.5)
	return
	


# define classes	
# switch class for branching into the corresponding move method
class pythonSwitch:
#	def __init__(self):		#default constructor
#		import Adafruit_BBIO.GPIO as GPIO;	#setup pinouts
#		GPIO.setup("P9_16", GPIO.OUT);		#set L293D enable pins to active
#		GPIO.setup("P9_27", GPIO.OUT);
#		GPIO.setup("P8_13", GPIO.OUT);
	def switch(self, moveType):		#switch
		default = "Invalid move";	#default case defined here
		return getaddr(self, 'case_' + str(moveType), lambda:
	def case_1(self):	#move from left to mid
		liftDrop(moveType)
		#move yaw to mid
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("P8_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#return arm to default position
		GPIO.output("P8_12",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("P8_12",GPIO.LOW);
		time.sleep(0.8)
		return;
	def case_2(self):	#move from left to right
		liftDrop(moveType)
		#move yaw to mid
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("P9_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#return arm to default position
		GPIO.output("P8_12",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("8_12",GPIO.LOW);
		time.sleep(0.8)
		return;
	def case_3(self):	#move from mid to left
		#move arm to mid
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("8_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#move yaw to mid
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("P8_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#return arm to default position
		GPIO.output("P8_12",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("P8_12",GPIO.LOW);
		time.sleep(0.8)
		return;
	def case_4(self):	#move from mid to right
		#move arm to mid
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("8_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#move yaw to mid
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("P9_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#return arm to default position
		GPIO.output("P8_12",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("8_12",GPIO.LOW);
		time.sleep(0.8)
		return;
	def case_5(self):	#move from right to left
		#move arm to right
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("8_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#move yaw to mid
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("P9_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#return arm to default position
		GPIO.output("P8_12",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("8_12",GPIO.LOW);
		time.sleep(0.8)
		return;
	def case_6(self):	#move from right to mid
		#move arm to right
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("8_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#move yaw to mid
		GPIO.output("P8_9",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("P9_9",GPIO.LOW);
		time.sleep(0.8)
		liftDrop(moveType)
		#return arm to default position
		GPIO.output("P8_12",GPIO.HIGH);
		time.sleep()	#TO-DO define function for yaw distance
		GPIO.output("8_12",GPIO.LOW);
		time.sleep(0.8)
		return;
#



#=== main() ===
# declare variables
moveOrder = [];		#empty list/array of move commands

#initialize GPIO pin modes
GPIO.setup("P8_26",GPIO.IN);
GPIO.setup("P9_12",GPIO.OUT)
GPIO.setup("P9_13",GPIO.OUT)
GPIO.setup("P9_16",GPIO.OUT)
GPIO.setup("P9_23",GPIO.OUT)
GPIO.setup("P9_26",GPIO.OUT)
GPIO.setup("P9_27",GPIO.OUT)
GPIO.setup("P8_9",GPIO.OUT)
GPIO.setup("P8_12",GPIO.OUT)
GPIO.setup("P8_13",GPIO.OUT)
GPIO.add_event_detect("P8_26",GPIO.RISING)	#allow P8_26 to trigger events
GPIO.output("P9_16",GPIO.HIGH)	#set L293D enable pins to active
GPIO.output("P9_27",GPIO.HIGH)
GPIO.output("P8_13",GPIO.HIGH)

# wait for start signal from start button
ctrl = 0
while ctrl==0:
	if GPIO.event_detected("P8_26"):	#begin ToH demonstration upon receiving button signal
		ctrl = 1
		ToHMoves(moveOrder);
		ToHWork(moveOrder)
	time.sleep(0.2)
print("Program finished.")
GPIO.cleanup()
return
