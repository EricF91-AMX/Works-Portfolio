#include <iostream>

#include <cstdlib>

using namespace std;

// function declarations

void displayMenu();

void displayChest();

void displayArms();

void displayLegs();

void displayCardio();

void displayBack();

int main() {

    int ch;

    // loop until valid choice is selected

    while (true) {

        displayMenu();

        cout << "\nEnter Choice: ";

        cin >> ch;

        // switch the user choice

        switch(ch) {

            case 1: displayChest(); break;

            case 2: displayArms(); break;

            case 3: displayLegs(); break;

            case 4: displayCardio(); break;

            case 5: displayBack(); break;

            case 0: exit(0);

            default: cout << "Invalid choice!! Try again.\n";

        }
    }
    return 0;
}

// function to display the main menu

void displayMenu() {

    cout << "\n-------Exercise Planner-------\n";

    cout << "\nMenu\n";

    cout << "1. Chest\n";

    cout << "2. Arms\n";

    cout << "3. Legs\n";

    cout << "4. Cardio\n";

    cout << "5. Back\n";

    cout << "0. Exit\n";

}

// function to generate 5 random numbers

void generateRandom(int arr[], int x) {

    int indx = 0, num;

    for (int c = 0; c < 5; c++) {

        do {

            num = rand()%x + 1;

            for (int i = 0; i < 5; i++) {

                if(num == arr[i]){

                    num = 0;

                    break;

                }

            }

        } while(num == 0);

        arr[indx] = num;

        indx++;

    }

}

// function to display exercises and choose random

void displayRandom(string list[], int size) {

    // display the exercise list

    for (int i = 0; i < size; i++) {

        cout << i+1 << " " << list[i] << endl;

    }

    char ch;

    cout << "\nPress H to pick 5 random exercises: ";

    cin >> ch;

    if (!(ch == 'H' || ch == 'h')) {

        cout << "Returning to main menu..\n";

        return;

    }

    int random[5];

    // genratee random numbers

    generateRandom(random, size);

    cout << "Randomly picked exercises are: \n";

    // display random exercises

    for (int i = 0; i < 5; i++) {

        cout << i+1 << " " << list[random[i]] << endl;

    }

    cout << "\nPress any alphabet to continue.";

    cin >> ch;

}

// chest exercises

void displayChest() {

    string list[] = {"Barbell Bench Press", "Flat Bench Press", "Low_incline Barbell Bench Press", "Machine Decline Press", "Seated Machine Chest Press", "Incline Dumbell Press", "Dips for Chest", "Incline Bench Cable Fly", "Incline Dumbbell Pull-Over", "Pec-Deck Machine"};

    int size = sizeof(list)/sizeof(*list);

    cout << "\nList of chest exercises: \n";

    displayRandom(list, size);

}

// arms exercises

void displayArms() {

    string list[] = {"Hammer Curl", "Dip", "Chinup", "Diamond Pushup", "Neutral-Grip Triceps Extension", "Poundstone Curl", "Close-Grip Pushup", "EZ-Bar Preacher Curl", "Reverse Curl", "Overhead Press"};

    int size = sizeof(list)/sizeof(*list);

    cout << "\nList of arm exercises: \n";

    displayRandom(list, size);

}

// legs exercises

void displayLegs() {

    string list[] = {"Squats", "Lunges", "Plank leg lifts", "Single-leg deadlifts", "Stability ball knee tucks", "Step-ups", "Box jumps", "Speedskater jumps", "Bridge", "Chair pose"};

    int size = sizeof(list)/sizeof(*list);

    cout << "\nList of legs exercises: \n";

    displayRandom(list, size);

}

// cardio exercies

void displayCardio() {

    string list[] = {"Split snatches", "Squat Thrust Split Jumps", "Planck Jack", "Sakters", "Rollback", "Burpee Jump", "Mini-Band Frog Jumps", "Lateral Shuffle Taps"};

    int size = sizeof(list)/sizeof(*list);

    cout << "\nList of cardio exercises: \n";

    displayRandom(list, size);

}

// back exercises

void displayBack() {

    string list[] = {"Resistance band pull apart", "Quadruped dumbbell row", "Lat pulldown", "Wide dumbbell row", "Barbell deadlift", "Hyperextension", "Single-arm dumbbell row", "Renegade dumbbell row", "Wood chop", "TRX row", "Superman", "Reverse fly", "Pullup"};

    int size = sizeof(list)/sizeof(*list);

    cout << "\nList of back exercises: \n";

    displayRandom(list, size);

}
