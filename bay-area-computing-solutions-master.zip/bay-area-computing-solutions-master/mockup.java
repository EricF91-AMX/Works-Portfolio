/*
 * Program conversion from C++ to Java.
 * Original creator was David Dinh
 * Exact style from the C++ file for easier readability to understand
 *  Future:
 *  	Convert into OOP as an example
 */

/*
 * Packages are used in Java in order to prevent naming conflicts, to control access,
 * to make searching/locating and usage of classes, interfaces, enumerations and annotations easier, etc.
 * All package names need to be unique
 */
package mockUpProgram;

/*
 * Lazy version of importing all the legacy libraries for java
 * C++ Ex:
 * 	#include <iostream>
 * 	#include <fstream> etc
 */
import java.util.*;

/*
 * All Java programs need at least one class to run anything
 */
public class Hello {
	/*
	 * variable sc to use user input: Scanner Library
	 * variable rand to use randomizer: Random Library
	 * All Libraries came from java.util.*
	 */
	static Scanner sc = new Scanner(System.in);
	static Random rand = new Random();

	/*
	 * Function to print out all the options
	 * Needed to change cout and remove <<
	 * And add public void to function definition
	 */
	public static void displayMenu() {
		System.out.println("\n-------Exercise Planner-------\n");
		System.out.println("\nMenu\n");
		System.out.println("1. Chest\n");
		System.out.println("2. Arms\n");
		System.out.println("3. Legs\n");
		System.out.println("4. Cardio\n");
		System.out.println("5. Back\n");
		System.out.println("0. Exit\n");
	}

	/*
	 * get random selection of 5 workouts when user
	 * wants to randomize.
	 * Add public void to function definition
	 */
	public static void generateRandom(int arr[], int x) {
		int indx = 0, num;
		for (int c = 0; c < 5; c++) {
			do {
				num = rand.nextInt(x);
				for (int i = 0; i < 5; i++)
				{
					if(num == arr[i]){
						num = 0;
						break;
					}
				}
			} while(num == 0);
			arr[indx] = num;
			indx++;
		}
	}
	/*
	 * Print randomized workout and user can quit by pressing any button
	 * except H or h
	 * Add public void to function definition 
	 */
	public static void displayRandom(String list[], int size) {
		// display the exercise list
		for (int i = 0; i < size; i++)
			System.out.println(i+1 + " " + list[i]);

		System.out.print("\nPress H to pick 5 random exercises: ");
	
		//user input to quit or move on
		char ch = sc.next().charAt(0);
		
		//if user enters anything except H or h, return to menu
		if (!(ch == 'H' || ch == 'h')) {
			System.out.println("Returning to main menu..\n");
			return;
		}
		int random[] = new int[5];

		// generate random numbers
		generateRandom(random, size);
		System.out.println("Randomly picked exercises are: ");

		// display random exercises
		for (int i = 0; i < 5; i++) {
			System.out.println(i+1 + " " + list[random[i]]);
		}
		//User can move on when he/she enters any character
		System.out.print("\nPress any alphabet to continue.");
		ch = sc.next().charAt(0);
	}
	
	/*
	 * Display chest workouts
	 * All workouts are hard coded into an array called list
	 * Add public void to function definition
	 */
	public static void displayChest() {

		String list[] = {"Barbell Bench Press", "Flat Bench Press", "Low_incline Barbell Bench Press",
				"Machine Decline Press", "Seated Machine Chest Press", "Incline Dumbell Press",
				"Dips for Chest", "Incline Bench Cable Fly", "Incline Dumbbell Pull-Over", "Pec-Deck Machine"};
		System.out.println("\nList of chest exercises: ");
		displayRandom(list, list.length);
	}

	/*
	 * Display arm workouts
	 * All workouts are hard coded into an array called list
	 * Add public void to function definition
	 */
	public static void displayArms() {

		String list[] = {"Hammer Curl", "Dip", "Chinup", "Diamond Pushup", "Neutral-Grip Triceps Extension",
				"Poundstone Curl", "Close-Grip Pushup", "EZ-Bar Preacher Curl", "Reverse Curl", "Overhead Press"};
		System.out.println("\nList of arm exercises: ");
		displayRandom(list, list.length);
	}

	/*
	 * Display leg workouts
	 * All workouts are hard coded into an array called list
	 * Add public void to function definition
	 */
	public static void displayLegs() {

		String list[] = {"Squats", "Lunges", "Plank leg lifts", "Single-leg deadlifts", "Stability ball knee tucks",
				"Step-ups", "Box jumps", "Speedskater jumps", "Bridge", "Chair pose"};
		System.out.println("\nList of legs exercises: ");
		displayRandom(list, list.length);
	}

	/*
	 * Display cardio workouts
	 * All workouts are hard coded into an array called list
	 * Add public void to function definition
	 */
	public static void displayCardio() {

		String list[] = {"Split snatches", "Squat Thrust Split Jumps", "Planck Jack", "Sakters",
				"Rollback", "Burpee Jump", "Mini-Band Frog Jumps", "Lateral Shuffle Taps"};
		System.out.println("\nList of cardio exercises: ");
		displayRandom(list, list.length);
	}

	/*
	 * Display arm workouts
	 * All workouts are hard coded into an array called list
	 * Add public void to function definition
	 */
	public static void displayBack() {

		String list[] = {"Resistance band pull apart", "Quadruped dumbbell row", "Lat pulldown",
				"Wide dumbbell row", "Barbell deadlift", "Hyperextension", "Single-arm dumbbell row",
				"Renegade dumbbell row", "Wood chop", "TRX row", "Superman", "Reverse fly", "Pullup"};
		System.out.println("\nList of back exercises: ");
		displayRandom(list, list.length);
	}
	
	/*
	 * *************************************
	 * 	Start of Main
	 * *************************************
	 */
	public static void main(String[] args) {

		int ch;
		// loop until valid choice is selected
		while (true) {
			displayMenu();
			System.out.print("\nEnter Choice: ");
			ch = sc.nextInt();
			
			// switch to the user choice
			switch(ch) {

			case 1: displayChest(); break;
			case 2: displayArms(); break;
			case 3: displayLegs(); break;
			case 4: displayCardio(); break;
			case 5: displayBack(); break;
			//exit program
			case 0: System.out.print("Exiting Goodbye");System.exit(0);
			//when user does not enter a value from 0-5
			default: System.out.println("Invalid choice!! Try again.");
			}
		}
	}
}
