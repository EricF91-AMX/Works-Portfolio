import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.*;

// Class to hold in all information regarding work out
class workout
{
	String workoutSession;
	int reps;
	String descrip;
}

public class FitnessApp {

	public static void main(String[] args) throws FileNotFoundException
	{
		// Creating files to be opened for txt files with work out informations
		File backFile = new File("BackWorkout.txt");
		File armFile = new File("ArmWorkout.txt");
		File cardioFile = new File("CardioWorkout.txt");
		File chestFile = new File("ChestWorkout.txt");
		File legFile = new File("LegWorkout.txt");

		// Vectors to hold the classes with information on work outs
		Vector <workout> backList = new Vector <workout>();
		Vector <workout> armList = new Vector <workout>();
		Vector <workout> cardioList = new Vector <workout>();
		Vector <workout> chestList = new Vector <workout>();
		Vector <workout> legList = new Vector <workout>();

		public static <T> Object[] convertVectorToArray(Vector<T> vector)
    {
        Object[] array = vector.toArray();

        return array;
    }
    public static void main(String args[])
    {
        // Creating linked list
        Vector<String>
            vector = new Vector<String>();

        // Adding elements to the linked list
        vector.add("BackWorkout.txt");
        vector.add("ArmWorkout.txt");
        vector.add("CardioWorkout.txt");
        vector.add("ChestWorkout.txt");
        vector.add("LegWorkout.txt");

		// Add Vector elements to Object Array
		Object[] objArray = convertVectorToArray(vector);

		//Convert Object Array to String Array

		String[] array = vector.toArray(new String[vector.size()]);

		// creating a scanner to go through list of each work out type
		Scanner backScan = new Scanner(backFile);
		Scanner armScan = new Scanner(armFile);
		Scanner cardioScan = new Scanner(cardioFile);
		Scanner chestScan = new Scanner(chestFile);
		Scanner legScan = new Scanner(legFile);

		// Arrays to hold the split entries in one line
		String[] backLine;
		String[] armLine;
		String[] cardioLine;
		String[] chestLine;
		String[] legLine;

		// Shoving all the work out information into the arrays
		while(backScan.hasNextLine())
		{
			workout back = new workout();
			backLine = backScan.nextLine().split(";");
			back.workoutSession = backLine[0];
			back.reps = Integer.parseInt(backLine[1]);
			back.descrip = backLine[2];
			backList.add(back);
		}
		while(armScan.hasNextLine())
		{
			workout arm = new workout();
			armLine = armScan.nextLine().split(";");
			arm.workoutSession = armLine[0];
			arm.reps = Integer.parseInt(armLine[1]);
			arm.descrip = armLine[2];
			armList.add(arm);
		}
		while(cardioScan.hasNextLine())
		{
			workout cardio = new workout();
			cardioLine = cardioScan.nextLine().split(";");
			cardio.workoutSession = cardioLine[0];
			cardio.reps = Integer.parseInt(cardioLine[1]);
			cardio.descrip = cardioLine[2];
			cardioList.add(cardio);
		}
		while(chestScan.hasNextLine())
		{
			workout chest = new workout();
			chestLine = chestScan.nextLine().split(";");
			chest.workoutSession = chestLine[0];
			chest.reps = Integer.parseInt(chestLine[1]);
			chest.descrip = chestLine[2];
			chestList.add(chest);
		}
		while(legScan.hasNextLine())
		{
			workout leg = new workout();
			legLine = legScan.nextLine().split(";");
			leg.workoutSession = legLine[0];
			leg.reps = Integer.parseInt(legLine[1]);
			leg.descrip = legLine[2];
			legList.add(leg);
		}
		System.lineSeparator();

		// Menu to decide what action to partake
		int choice = 0;
		Scanner input = new Scanner(System.in);

		do
		{
			System.out.println("What would you like to do?(Enter corresponding menu number)");
			System.out.println("----------------------------------");
			System.out.println("1. Print all work outs");
			System.out.println("2. Print back work outs");
			System.out.println("3. Print arm work outs");
			System.out.println("4. Print cardio work outs");
			System.out.println("5. Print chest work outs");
			System.out.println("6. Print leg work outs");
			System.out.println("0. Exit");
			System.out.println("Choice: ");
			choice = input.nextInt();

			if(choice < 0 | choice > 6)
				System.out.println("This choice does not exist, please try again");
			System.out.println();

			switch(choice)
			{
				// Printing all work outs
				case 1:
					System.out.println("List of Back Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < backList.size(); i++)
					{
						System.out.println("Workout: " + backList.get(i).workoutSession + " | Suggested Reps: " + backList.get(i).reps + " | Decription: " + backList.get(i).descrip);
					}
					System.out.println();
					System.out.println("List of Arm Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < armList.size(); i++)
					{
						System.out.println("Workout: " + armList.get(i).workoutSession + " | Suggested Reps: " + armList.get(i).reps + " | Decription: " + armList.get(i).descrip);
					}
					System.out.println();
					System.out.println("List of Cardio Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < cardioList.size(); i++)
					{
						System.out.println("Workout: " + cardioList.get(i).workoutSession + " | Suggested Reps: " + cardioList.get(i).reps + " | Decription: " + cardioList.get(i).descrip);
					}
					System.out.println();
					System.out.println("List of Chest Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < chestList.size(); i++)
					{
						System.out.println("Workout: " + chestList.get(i).workoutSession + " | Suggested Reps: " + chestList.get(i).reps + " | Decription: " + chestList.get(i).descrip);
					}
					System.out.println();
					System.out.println("List of Leg Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < legList.size(); i++)
					{
						System.out.println("Workout: " + legList.get(i).workoutSession + " | Suggested Reps: " + legList.get(i).reps + " | Decription: " + legList.get(i).descrip);
					}
					System.out.println();
					break;

				// Printing back work outs
				case 2:
					System.out.println("List of Back Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < backList.size(); i++)
					{
						System.out.println("Workout: " + backList.get(i).workoutSession + " | Suggested Reps: " + backList.get(i).reps + " | Decription: " + backList.get(i).descrip);
					}
					System.out.println();
					break;

				// Printing arm work outs
				case 3:
					System.out.println("List of Arm Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < armList.size(); i++)
					{
						System.out.println("Workout: " + armList.get(i).workoutSession + " | Suggested Reps: " + armList.get(i).reps + " | Decription: " + armList.get(i).descrip);
					}
					System.out.println();
					break;

				// Printing cardio work outs
				case 4:
					System.out.println("List of Cardio Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < cardioList.size(); i++)
					{
						System.out.println("Workout: " + cardioList.get(i).workoutSession + " | Suggested Reps: " + cardioList.get(i).reps + " | Decription: " + cardioList.get(i).descrip);
					}
					System.out.println();
					break;

				// Printing chest work outs
				case 5:
					System.out.println("List of Chest Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < chestList.size(); i++)
					{
						System.out.println("Workout: " + chestList.get(i).workoutSession + " | Suggested Reps: " + chestList.get(i).reps + " | Decription: " + chestList.get(i).descrip);
					}
					System.out.println();
					break;

				// Printing leg work outs
				case 6:
					System.out.println("List of Leg Work Outs:");
					System.out.println("-------------------------");
					for(int i = 0; i < legList.size(); i++)
					{
						System.out.println("Workout: " + legList.get(i).workoutSession + " | Suggested Reps: " + legList.get(i).reps + " | Decription: " + legList.get(i).descrip);
					}
					System.out.println();
					break;
			}
		}while(choice != 0);

		// Closing all scanners
		backScan.close();
		armScan.close();
		cardioScan.close();
		chestScan.close();
		legScan.close();
		input.close();
		System.out.println("Have a nice day");
	}
}
