package com.example.workthrough;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;

import java.text.SimpleDateFormat;


public class MainActivity extends AppCompatActivity
{
    /*
        Create Main Menu when application starts or when
        user exits from certain pages
    */
    String selectedDate = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
            variables to manipulate application GUI objects
        */
        Button createBtn = (Button) findViewById(R.id.createBtn);
        Button resultsBtn = (Button) findViewById(R.id.resultsBtn);
        Button viewBtn = (Button) findViewById(R.id.viewBtn);
        CalendarView calendar = (CalendarView) findViewById(R.id.calendarWidg);

        /*
            functions to switch pages when certain buttons are clicked/tapped.
            create == switch to Create Page
            results == switch to ViewResults Page
            view == switch to ViewWorkout Page
        */
        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentDate = getSelectedDate();
                openActivity("create", currentDate);
            }
        });
        resultsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentDate = getSelectedDate();
                openActivity("results", currentDate);
            }
        });
        viewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentDate = getSelectedDate();
                openActivity("view", currentDate);
            }
        });
        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int day) {
                String currDate = (month + 1) + "" + day + "" + year;
                setSelectedDate(currDate);
                Log.d("currDate",currDate);
            }
        });

    }

    private void setSelectedDate(String date) {
        selectedDate = date;
    }
    private String getSelectedDate() { return selectedDate;}


    /*
        Functions to switch pages within the application
    */
        public void openActivity (String page, String data)
        {
            if (page == "create") {
                Intent intent = new Intent(this, CreateWorkout.class);
                intent.putExtra("date", data);
                startActivity(intent);
            } else if (page == "results") {
                Intent intent = new Intent(this, ViewResults.class);
                intent.putExtra("date", data);
                startActivity(intent);
            } else if (page == "view") {
                Intent intent = new Intent(this, ViewWorkout.class);
                intent.putExtra("date", data);
                startActivity(intent);
            }
        }

        public String setCalendarDate(CalendarView cal) {
            SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
            String date = sdf.format(cal.getDate());
            return date;
        }
}
