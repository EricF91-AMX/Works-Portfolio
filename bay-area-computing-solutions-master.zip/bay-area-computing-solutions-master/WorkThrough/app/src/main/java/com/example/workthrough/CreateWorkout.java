package com.example.workthrough;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.util.ArrayList;

public class CreateWorkout extends AppCompatActivity {

    private String file = "file";
    private String date = "";
    /*
        Creates the Create page when user clicks Create in Main Menu
     */
     
    /* Boolean DoneCreation;
    {
        DoneCreation = false;
    }
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_workout);
        /*
            Variables for app objects to manipulate GUI
        */
        Button exitBtn = (Button) findViewById(R.id.exitBtn);
        Button addBtn = (Button) findViewById(R.id.addBtn);
        /*
            Set variables to switch pages when clicked/tapped
        */

        /*
            Preset workout list for debugging purposes
         */
        ArrayList<String> workout = new ArrayList<String>();
        String[] Array = {"Bench Press", "Squat", "Deadlift"};
        for (int i = 0; i < 3;i++)
            workout.add(Array[i]);

        /*
            Grab data from previous activity by using Intent and Bundle
         */
        Intent grab = getIntent();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            if (extras.getStringArrayList("workoutList") != null) {
                workout = grab.getStringArrayListExtra("workoutList");
            }
            if (extras.getString("selectedWorkout") != null) {
                String selectWork = grab.getStringExtra("selectedWorkout");
                workout.add(selectWork);
            }
            if (extras.getString("date") != null) {
                String date = grab.getStringExtra("date");
                Log.d("createNewDate",date);
            }
            else
                Log.d("fail","nothing in Intent");
        }
        /*
            Gets the ListView object and prints out the array into a list.
            ArrayAdapter helps listView with analyzing the list.
            Passing parameter: Array is the hard coded array.
        */
        Log.d("length", String.valueOf(workout.size()));
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, workout);
        ListView bodyList = (ListView)findViewById(R.id.workListSelect);
        bodyList.setAdapter(adapter);

        /*
            Exit activity and store workout list into Intent
         */
        final ArrayList<String> finalWork = workout;
        exitBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) { openActivity("Exit",finalWork); }
        });
        addBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) { openActivity("Add",finalWork); }
        });
    }

    /*
        Function is used to switch pages within the application.
    */
    public void openActivity(String page, ArrayList<String> workout)
    {
        if ( page == "Exit")
        {
            Intent mainPage = new Intent(this, MainActivity.class);
            mainPage.putExtra("date",date);
            mainPage.putExtra("workoutList",workout);
            startActivity(mainPage);
        }
        else if ( page == "Add")
        {
            Intent addPage = new Intent( this, AddWorkout.class);
            addPage.putExtra("date",date);
            addPage.putExtra("workoutList",workout);
            startActivity(addPage);
        }
    }
}
