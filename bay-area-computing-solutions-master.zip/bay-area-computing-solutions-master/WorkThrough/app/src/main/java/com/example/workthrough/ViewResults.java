package com.example.workthrough;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.FileInputStream;

public class ViewResults extends AppCompatActivity {
    /*
        File to read information from for user to see typed in results
        Name needs migrate to calendar format for day to day
        consistency.
    */
    private String file = "logFile";
    private String date = "";
    /*
        Create View Results page when user clicks/taps Results in main menu
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_results);
        /*
            variables for application objects to manipulate GUI
        */
        Button exitBtn = (Button) findViewById(R.id.exitBtn);
        Button editBtn = (Button) findViewById(R.id.editBtn);
        final TextView userInput = (TextView) findViewById(R.id.userInput);

        /*
            Functionality to get data from previous Activity
         */
        Intent grab = getIntent();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            if (extras.getString("date") != null) {
                date = grab.getStringExtra("date");
                file = date + "_results";
                Log.d("createNewDate",date);
            }
            else
                Log.d("fail","nothing in Intent");
        }
        /*
            Read file from internal storage and print out data
            onto textView in the viewResults Page
            It reads in bytes, which is why it needs to be converted to String
        */
        try
        {
            FileInputStream fIn = openFileInput(file);
            int c;
            String line = "";
            while ((c = fIn.read()) != -1)
            {
                line = line + Character.toString((char)c);
            }
            userInput.setText(line);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        /*
            functions to switch pages when user clicks/taps on the buttons
            Exit == Switch to Main Menu
            Edit == Switch to Edit Results Page.
                -When User switch to Edit page, all previous results will be deleted.
        */
        exitBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) { openActivity("Exit",date); }
        });
        editBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openActivity("Edit",date);
            }
        });
    }


    /*
        Function to switch application pages
    */
    public void openActivity(String page, String data)
    {
        if ( page == "Exit")
        {
            Intent mainPage = new Intent(this, MainActivity.class);
            mainPage.putExtra("date", data);
            startActivity(mainPage);
        }
        else if ( page == "Edit")
        {
            Intent editPage = new Intent( this, editTextFile.class);
            editPage.putExtra("date", data);
            startActivity(editPage);
        }
    }
}
