package com.example.workthrough;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

public class editTextFile extends AppCompatActivity {
    /*
        Current file name whenever user saves their results
        Will use the calendar and date soon, need to pass date info
        through Bundle
    */
    private String file = "logFile";
    private String fileContents;
    private String date;

    /*
        Create Edit Results page when user taps/clicks in ViewResults page
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_text_file);

        /*
            variables to use application objects to manipulate GUI
        */
        Button exitBtn = (Button) findViewById(R.id.exitBtn);
        Button saveBtn = (Button) findViewById(R.id.saveBtnForAdd);
        final EditText userInput = (EditText) findViewById(R.id.userInputTxt);

        /*
            Functionality to get data from previous Activity
         */
        Intent grab = getIntent();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            if (extras.getString("date") != null) {
                date = grab.getStringExtra("date");
                file = date + "_results";
                Log.d("createNewDate",date);
            }
            else
                Log.d("fail","nothing in Intent");
        }
        /*
            Function to exit back to ViewResults page when Exit is clicked/tapped
        */
        exitBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) { openActivity("Exit",date); }
        });
        /*
            Function to save user's typed in results into file
            Every time user hits save, it will override the file.
        */
        saveBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                fileContents = userInput.getText().toString();
                try
                {
                    FileOutputStream fOut = openFileOutput(file, MODE_PRIVATE);
                    fOut.write(fileContents.getBytes());
                    fOut.close();
                    File fileDir = new File(getFilesDir(), file);
                    Toast.makeText(getBaseContext(), "File Saved at " + fileDir, Toast.LENGTH_LONG).show(); //debugging functionality
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
    }

    /*
        Function to switch pages when user clicks/taps on the button
    */
    public void openActivity(String page,String data)
    {
        if ( page == "Exit")
        {
            Intent mainPage = new Intent(this, ViewResults.class);
            mainPage.putExtra("date", data);
            startActivity(mainPage);
        }
    }
}
