package com.example.workthrough;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class ViewWorkout extends AppCompatActivity {
    /*
        Once the import of the code is done in AddWorkout the display can be pushed in
        Public Bool
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_workout);
        
            Boolean isCreationDone = false;

if(isCreationDone == true){
    Toast.makeText(this, "Workout Created for the day" +
            "Now displaying",
            Toast.LENGTH_LONG).show();
    }
// add the method to display in this if statement

else{
    Toast.makeText(this, "Battery is NOT charging!" +
                    "Plug in the charger!",
            Toast.LENGTH_LONG).show();
    }
        /*
        fatal error occurred when two buttons to allow the user to navigate from this page
        to the addworkout/createworkout/mainactivity
        buttons added to the XML
        
        Button createBtn = (Button) findViewById(R.id.createBtn);
        Button exitBtn = (Button) findViewById(R.id.exitBtn);
        */
    }
}
