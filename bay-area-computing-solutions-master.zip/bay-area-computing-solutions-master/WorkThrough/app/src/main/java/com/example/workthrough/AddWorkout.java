package com.example.workthrough;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ArrayAdapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class AddWorkout extends AppCompatActivity {

    //variables
    ArrayList<String> bodyArr = new ArrayList<String>();
    ArrayList<String> backArr = new ArrayList<String>();
    ArrayList<String> armArr = new ArrayList<String>();
    ArrayList<String> chestArr = new ArrayList<String>();
    ArrayList<String> legArr = new ArrayList<String>();
    ArrayList<String> workout = new ArrayList<String>();
    private String date = "";
    /*
        Create Add page when user taps Add in Create Menu
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_workout);

        final Button saveButton = (Button) findViewById(R.id.saveBtnForAdd);

        /*
            Reading all text files to store lists into arrayLists
         */
        readFile("bodyParts.txt", bodyArr);
        readFile("workouts/BackWorkout.txt", backArr);
        readFile("workouts/ChestWorkout.txt", chestArr);
        readFile("workouts/LegWorkout.txt", legArr);
        readFile("workouts/ArmWorkout.txt", armArr);

        /*
            Grab data from previous activity by using Intent and Bundle
         */
        Intent grab = getIntent();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            if (extras.getStringArrayList("workoutList") != null) {
                workout = grab.getStringArrayListExtra("workoutList");
            }

            if (extras.getString("date") != null) {
                String date = grab.getStringExtra("date");
                Log.d("createNewDate",date);
            }
            else
                Log.d("fail","nothing in Intent");
        }
        /*
            Pass in bodyArr through ArrayAdapter as the last parameter
            bodyList is a variable to use the app object ListView.
            Print out bodyArr into ListView.
        */
        final ArrayAdapter adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, bodyArr);
        ListView bodyList = (ListView)findViewById(R.id.bodyList);
        bodyList.setAdapter(adapter);

        /*
             Adapters needed to print out the lists onto the application
         */
        final ArrayAdapter adapterB = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, backArr);
        final ListView backList = (ListView)findViewById(R.id.ListOfWorkouts);

        final ArrayAdapter adapterC = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, chestArr);
        final ListView chestList = (ListView)findViewById(R.id.ListOfWorkouts);

        final ArrayAdapter adapterL = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, legArr);
        final ListView legList = (ListView)findViewById(R.id.ListOfWorkouts);

        final ArrayAdapter adapterA = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, armArr);
        final ListView armList = (ListView)findViewById(R.id.ListOfWorkouts);

        /*
            Whenever the user taps on a body part, it will print out the list of workouts for
            that body part. If the user selects a workout and hits save, it will save the
            workout and send it to the next activity.
        */
        bodyList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String value = (String) adapter.getItem(position);
                if (value.equals("Back") == true) {
                    backList.setAdapter(adapterB);
                    backList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            final String selectedWorkout = (String) adapterB.getItem(position);
                            saveButton.setOnClickListener(new View.OnClickListener() {

                                @Override
                                public void onClick(View v) {
                                    workout.add(selectedWorkout);
                                    final ArrayList<String> finalWork = workout;
                                    openActivity("Create",finalWork);
                                    Log.d("something",selectedWorkout);
                                }
                            });
                        }
                    });
                }
                if (value.equals("Chest") == true) {
                    chestList.setAdapter(adapterC);
                    chestList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            final String selectedWorkout = (String) adapterC.getItem(position);
                            saveButton.setOnClickListener(new View.OnClickListener() {

                                @Override
                                public void onClick(View v) {
                                    workout.add(selectedWorkout);
                                    final ArrayList<String> finalWork = workout;
                                    openActivity("Create",finalWork);
                                    Log.d("something",selectedWorkout);
                                }
                            });
                        }
                    });
                }
                if (value.equals("Legs") == true) {
                    legList.setAdapter(adapterL);
                    legList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            final String selectedWorkout = (String) adapterL.getItem(position);
                            saveButton.setOnClickListener(new View.OnClickListener() {

                                @Override
                                public void onClick(View v) {
                                    workout.add(selectedWorkout);
                                    final ArrayList<String> finalWork = workout;
                                    openActivity("Create",finalWork);
                                    Log.d("something",selectedWorkout);
                                }
                            });
                        }
                    });
                }
                if (value.equals("Arms") == true) {
                    armList.setAdapter(adapterA);
                    armList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            final String selectedWorkout = (String) adapterA.getItem(position);
                            saveButton.setOnClickListener(new View.OnClickListener() {

                                @Override
                                public void onClick(View v) {
                                    workout.add(selectedWorkout);
                                    final ArrayList<String> finalWork = workout;
                                    openActivity("Create",finalWork);
                                    Log.d("something",selectedWorkout);
                                }
                            });
                        }
                    });
                }
            }
        });



        /*
            Switch to Create Menu when user clicks on Exit
            Add has no function yet as it needs populated workouts for each
            body part first
        */
        final Button exitBtn = (Button) findViewById(R.id.exitBtn);
        exitBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) { openActivity("Exit",workout); }
        });

    }
    /*
        Function to switch pages within the application
    */
    public void openActivity(String page, ArrayList<String> data)
    {
        if ( page == "Exit")
        {
            Intent mainPage = new Intent(this, CreateWorkout.class);
            mainPage.putExtra("date",date);
            mainPage.putExtra("workoutList",data);
            startActivity(mainPage);
        }
        else if ( page == "Create")
        {
            Intent addPage = new Intent( this, CreateWorkout.class);
            addPage.putExtra("date",date);
            addPage.putExtra("workoutList", data);
            startActivity(addPage);
        }
    }
    /*
        Read text file list and store it into an arraylist
     */
    public void readFile(String file, ArrayList<String> arr) {
        try {
            String str = "";
            StringBuffer buf = new StringBuffer();
            InputStream is = getAssets().open(file);
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                if (is != null) {
                    while ((str = reader.readLine()) != null) {
                        arr.add(str);
                    }
                }
            } finally {
                try { is.close(); } catch (Throwable ignore) {}
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
