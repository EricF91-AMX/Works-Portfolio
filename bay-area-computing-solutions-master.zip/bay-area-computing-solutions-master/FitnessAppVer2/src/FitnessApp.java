import java.io.*;
import java.util.Scanner;
import java.util.*;
import java.util.Random;

// Class to hold in all information regarding work out
class workout
{
	String workoutSession;
	int reps;
	String descrip;
}

class routines
{
	ArrayList <workout> rout; 
}

public class FitnessApp {

	public static void main(String[] args) throws NumberFormatException, IOException 
	{
		// Creating files to be opened for txt files with work out informations 
		File backFile = new File("BackWorkout.txt");
		File armFile = new File("ArmWorkout.txt");
		File cardioFile = new File("CardioWorkout.txt"); 
		File chestFile = new File("ChestWorkout.txt");
		File legFile = new File("LegWorkout.txt");
		
		// Array Lists to hold the classes with information on work outs 
		ArrayList <workout> backList = new ArrayList <workout>();
		ArrayList <workout> armList = new ArrayList <workout>();
		ArrayList <workout> cardioList = new ArrayList <workout>();
		ArrayList <workout> chestList = new ArrayList <workout>();
		ArrayList <workout> legList = new ArrayList <workout>();
		
		// Array List containing all routines made stored in class "routines"
		ArrayList <routines> allRoutine = new ArrayList <routines>();
	
		// Creating a input reader to go through list of each work out type
		BufferedReader backScan = new BufferedReader(new FileReader(backFile));
		BufferedReader armScan = new BufferedReader(new FileReader(armFile));
		BufferedReader cardioScan = new BufferedReader(new FileReader(cardioFile));
		BufferedReader chestScan = new BufferedReader(new FileReader(chestFile));
		BufferedReader legScan = new BufferedReader(new FileReader(legFile));
		
		// Arrays to hold the tokens of one line
		String[] backLine;
		String[] armLine;
		String[] cardioLine;
		String[] chestLine;
		String[] legLine;
		
		// String to hold lines from files read
		String line;
		
		// Shoving all the work out information into the arrays
		while((line = backScan.readLine()) != null)
		{
			workout back = new workout();
			backLine = line.split(";");
			back.workoutSession = backLine[0];
			back.reps = Integer.parseInt(backLine[1]);
			back.descrip = backLine[2];
			backList.add(back);
		}
		while((line = armScan.readLine()) != null)
		{
			workout arm = new workout();
			armLine = line.split(";");
			arm.workoutSession = armLine[0];
			arm.reps = Integer.parseInt(armLine[1]);
			arm.descrip = armLine[2];
			armList.add(arm);
		}
		while((line = cardioScan.readLine()) != null)
		{
			workout cardio = new workout();
			cardioLine = line.split(";");
			cardio.workoutSession = cardioLine[0];
			cardio.reps = Integer.parseInt(cardioLine[1]);
			cardio.descrip = cardioLine[2];
			cardioList.add(cardio);
		}
		while((line = chestScan.readLine()) != null)
		{
			workout chest = new workout();
			chestLine = line.split(";");
			chest.workoutSession = chestLine[0];
			chest.reps = Integer.parseInt(chestLine[1]);
			chest.descrip = chestLine[2];
			chestList.add(chest);
		}
		while((line = legScan.readLine()) != null)
		{
			workout leg = new workout();
			legLine = line.split(";");
			leg.workoutSession = legLine[0];
			leg.reps = Integer.parseInt(legLine[1]);
			leg.descrip = legLine[2];
			legList.add(leg);
		}
		System.lineSeparator();
		
		////
		// Menu to decide which action to partake
		int choice = 0;
		int workoutChoice = 0;
		String workoutADD = "";
		Scanner input = new Scanner(System.in);
		
		do
		{
			System.out.println("What would you like to do?(Enter corresponding menu number)");
			System.out.println("----------------------------------");
			System.out.println("1. Print all work outs");
			System.out.println("2. Print back work outs");
			System.out.println("3. Print arm work outs");
			System.out.println("4. Print cardio work outs");
			System.out.println("5. Print chest work outs");
			System.out.println("6. Print leg work outs");
			System.out.println("7. Create a workout routine");
			System.out.println("8. Look at current workout routine");
			System.out.println("9. Look at previous workout routine");
			System.out.println("0. Exit");
			System.out.println("Choice: ");
			choice = input.nextInt();
			
			if(choice < 0 | choice > 9)
				System.out.println("This choice does not exist, please try again");
			System.out.println();
			
			switch(choice)
			{
			// Printing all work outs
			case 1:
				
				System.out.println("List of Back Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < backList.size(); i++)
				{
					System.out.println("Workout: " + backList.get(i).workoutSession + " | Suggested Reps: " + backList.get(i).reps + " | Decription: " + backList.get(i).descrip);
				}
				System.out.println();
				System.out.println("List of Arm Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < armList.size(); i++)
				{
					System.out.println("Workout: " + armList.get(i).workoutSession + " | Suggested Reps: " + armList.get(i).reps + " | Decription: " + armList.get(i).descrip);
				}
				System.out.println();
				System.out.println("List of Cardio Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < cardioList.size(); i++)
				{
					System.out.println("Workout: " + cardioList.get(i).workoutSession + " | Suggested Reps: " + cardioList.get(i).reps + " | Decription: " + cardioList.get(i).descrip);
				}
				System.out.println();
				System.out.println("List of Chest Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < chestList.size(); i++)
				{
					System.out.println("Workout: " + chestList.get(i).workoutSession + " | Suggested Reps: " + chestList.get(i).reps + " | Decription: " + chestList.get(i).descrip);
				}
				System.out.println();
				System.out.println("List of Leg Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < legList.size(); i++)
				{
					System.out.println("Workout: " + legList.get(i).workoutSession + " | Suggested Reps: " + legList.get(i).reps + " | Decription: " + legList.get(i).descrip);
				}		
				System.out.println();
				break;
			
			// Printing back work outs
			case 2:
				System.out.println("List of Back Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < backList.size(); i++)
				{
					System.out.println("Workout: " + backList.get(i).workoutSession + " | Suggested Reps: " + backList.get(i).reps + " | Decription: " + backList.get(i).descrip);
				}
				System.out.println();
				break;
			
			// Printing arm work outs
			case 3:
				System.out.println("List of Arm Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < armList.size(); i++)
				{
					System.out.println("Workout: " + armList.get(i).workoutSession + " | Suggested Reps: " + armList.get(i).reps + " | Decription: " + armList.get(i).descrip);
				}
				System.out.println();
				break;
				
			// Printing cardio work outs	
			case 4:
				System.out.println("List of Cardio Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < cardioList.size(); i++)
				{
					System.out.println("Workout: " + cardioList.get(i).workoutSession + " | Suggested Reps: " + cardioList.get(i).reps + " | Decription: " + cardioList.get(i).descrip);
				}
				System.out.println();
				break;
				
			// Printing chest work outs
			case 5:
				System.out.println("List of Chest Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < chestList.size(); i++)
				{
					System.out.println("Workout: " + chestList.get(i).workoutSession + " | Suggested Reps: " + chestList.get(i).reps + " | Decription: " + chestList.get(i).descrip);
				}
				System.out.println();
				break;
				
			// Printing leg work outs
			case 6:
				System.out.println("List of Leg Work Outs:");
				System.out.println("-------------------------");
				for(int i = 0; i < legList.size(); i++)
				{
					System.out.println("Workout: " + legList.get(i).workoutSession + " | Suggested Reps: " + legList.get(i).reps + " | Decription: " + legList.get(i).descrip);
				}		
				System.out.println();
				break;
				
			case 7:
				// Created routines stored in here
				ArrayList <workout> routine = new ArrayList <workout>();
				
				// Class to hold ArrayList of current routine to store into all Routine ArrayList
				routines routStorage = new routines();
				do
				{
					System.out.println("Which type of workout would you like to add?(Enter corresponding menu number)");
					System.out.println("1. Back");
					System.out.println("2. Arm");
					System.out.println("3. Cardio");
					System.out.println("4. Chest");
					System.out.println("5. Leg");
					System.out.println("6. Random Routine of 5 work outs");
					System.out.println("7. Routine finished");
					System.out.println("Choice: ");
					workoutChoice = input.nextInt();
					input.nextLine();
					
					if(workoutChoice < 0 | workoutChoice > 7)
						System.out.println("This choice does not exist, please try again");
					System.out.println();
					
					switch(workoutChoice)
					{
					// Adding back work outs to routine
					case 1:
						System.out.println("Which back workout would you like to add?(Enter name of workout)");
						for(int i = 0; i < backList.size(); i++)
						{
							System.out.println("Workout: " + backList.get(i).workoutSession);
						}
						System.out.println("Choice: ");
						workoutADD = input.nextLine();
						
						for(int i = 0; i < backList.size(); i++)
						{
							if(workoutADD.contentEquals(backList.get(i).workoutSession))
							{
								routine.add(backList.get(i));
								System.out.println("Workout has been added to routine");
								break;
							}
							if(i == backList.size() - 1)
								System.out.println("This workout does not exist");	
						}
						System.out.println();
						break;
						
					// Adding arm work outs to routine
					case 2:
						System.out.println("Which arm workout would you like to add?(Enter name of workout)");
						for(int i = 0; i < armList.size(); i++)
						{
							System.out.println("Workout: " + armList.get(i).workoutSession);
						}
						System.out.println("Choice: ");
						workoutADD = input.nextLine();
						
						for(int i = 0; i < armList.size(); i++)
						{
							if(workoutADD.contentEquals(armList.get(i).workoutSession))
							{
								routine.add(armList.get(i));
								System.out.println("Workout has been added to routine");
								break;
							}
							if(i == armList.size() - 1)
								System.out.println("This workout does not exist");	
						}
						System.out.println();
						break;
						
					// Adding Cardio work outs to routine
					case 3:
						System.out.println("Which cardio workout would you like to add?(Enter name of workout)");
						for(int i = 0; i < cardioList.size(); i++)
						{
							System.out.println("Workout: " + cardioList.get(i).workoutSession);
						}
						System.out.println("Choice: ");
						workoutADD = input.nextLine();
						
						for(int i = 0; i < cardioList.size(); i++)
						{
							if(workoutADD.contentEquals(cardioList.get(i).workoutSession))
							{
								routine.add(cardioList.get(i));
								System.out.println("Workout has been added to routine");
								break;
							}
							if(i == cardioList.size() - 1)
								System.out.println("This workout does not exist");	
						}
						System.out.println();
						break;
						
					// Adding chest work outs to routine
					case 4:
						System.out.println("Which chest workout would you like to add?(Enter name of workout)");
						for(int i = 0; i < chestList.size(); i++)
						{
							System.out.println("Workout: " + chestList.get(i).workoutSession);
						}
						System.out.println("Choice: ");
						workoutADD = input.nextLine();
						
						for(int i = 0; i < chestList.size(); i++)
						{
							if(workoutADD.contentEquals(chestList.get(i).workoutSession))
							{
								routine.add(chestList.get(i));
								System.out.println("Workout has been added to routine");
								break;
							}
							if(i == chestList.size() - 1)
								System.out.println("This workout does not exist");	
						}
						System.out.println();
						break;
						
					// Adding leg work outs to routine
					case 5:
						System.out.println("Which leg workout would you like to add?(Enter name of workout)");
						for(int i = 0; i < legList.size(); i++)
						{
							System.out.println("Workout: " + legList.get(i).workoutSession);
						}
						System.out.println("Choice: ");
						workoutADD = input.nextLine();
						
						for(int i = 0; i < legList.size(); i++)
						{
							if(workoutADD.contentEquals(legList.get(i).workoutSession))
							{
								routine.add(legList.get(i));
								System.out.println("Workout has been added to routine");
								break;
							}
							if(i == legList.size() - 1)
								System.out.println("This workout does not exist");		
						}
						System.out.println();
						break;
						
					// Random routine maker
					case 6:
						Random rand = new Random();
						int randType = 0;
						int randWorkout = 0;
						for(int i = 0; i < 5; i++)
						{
							randType = rand.nextInt(5) + 1;
							
							// Random Back work out
							if(randType == 1)
							{
								randWorkout = rand.nextInt(backList.size());
								routine.add(backList.get(randWorkout));
							}
							// Random Arm work out 
							else if(randType == 2)
							{
								randWorkout = rand.nextInt(armList.size());
								routine.add(armList.get(randWorkout));
							}
							// Random Cardio work out
							else if(randType == 3)
							{
								randWorkout = rand.nextInt(cardioList.size());
								routine.add(cardioList.get(randWorkout));
							}
							// Random Chest work out
							else if(randType == 4)
							{
								randWorkout = rand.nextInt(chestList.size());
								routine.add(chestList.get(randWorkout));
							}
							// Random Leg work out
							else if(randType == 5)
							{
								randWorkout = rand.nextInt(legList.size());
								routine.add(legList.get(randWorkout));
							}
						}
						
						System.out.println("Random Routine created");
						System.out.println("----------------------");
						for(int i = 0; i < routine.size(); i++)
						{
							System.out.println(routine.get(i).workoutSession);
						}
						System.out.println();
						workoutChoice = 0;
						
						// Storing routine
						routStorage.rout = routine;
						allRoutine.add(routStorage);
						
						break;
						
					// Exit out of routine maker
					case 7:
						workoutChoice = 0;
						System.out.println("Your Routine has been created");
						System.out.println();
						
						// Storing Routine
						routStorage.rout = routine;
						allRoutine.add(routStorage);
					}
				}while(workoutChoice != 0);
				break;
				
			// Showing latest routine made
			case 8:	
				// If no routines exist, exit out
				if(allRoutine.size() - 1 < 0)
				{
					System.out.println("No routines exist at all");
					System.out.println();
					break;
				}
				
				routines showRout = allRoutine.get(allRoutine.size() - 1);
				System.out.println("Current workout routine consists of");
				System.out.println("-------------------------------------");
				for(int i = 0; i < showRout.rout.size(); i++)
				{
					System.out.println(showRout.rout.get(i).workoutSession);
				}
				System.out.println();
				break;			
				
			// Checking previous routine created and prints it
			case 9:
				// If only one routine exists, exit out
				if(allRoutine.size() - 2 < 0)
				{
					System.out.println("There are no previous routine available to check");
					System.out.println();
					break;
				}
				
				routines prevRout = allRoutine.get(allRoutine.size() - 2);
				System.out.println("Previous workout routine consists of");
				System.out.println("-------------------------------------");
				for(int i = 0; i < prevRout.rout.size(); i++)
				{
					System.out.println(prevRout.rout.get(i).workoutSession);
				}
				System.out.println();
				break;			
				
			}
		}while(choice != 0);
		// End of menu 
		////
		
		// Closing all scanners 
		backScan.close();
		armScan.close();
		cardioScan.close();
		chestScan.close();
		legScan.close();
		input.close();
		System.out.println("Have a nice day");
	}
}