import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

// Class to hold in all information regarding work out
class workout
{
	String workoutSession;
	int reps;
	String descrip;
}

public class FitnessApp {

	public static void main(String[] args) throws FileNotFoundException 
	{
		
		// Creating files to be opened for txt files with work out informations 
		File backFile = new File("BackWorkout.txt");
		File armFile = new File("ArmWorkout.txt");
		File cardioFile = new File("CardioWorkout.txt"); 
		File chestFile = new File("ChestWorkout.txt");
		File legFile = new File("LegWorkout.txt");
		
		// Arrays to hold the classes with information on work outs 
		// Can be swapped for vectors if better
		workout backList[] = new workout[13];
		workout armList[] = new workout[10];
		workout cardioList[] = new workout[8];
		workout chestList[] = new workout[10];
		workout legList[] = new workout[10];
		
		// creating a scanner to go through list of each work out type
		Scanner backScan = new Scanner(backFile);
		Scanner armScan = new Scanner(armFile);
		Scanner cardioScan = new Scanner(cardioFile);
		Scanner chestScan = new Scanner(chestFile);
		Scanner legScan = new Scanner(legFile);
		
		// Arrays to hold the split entries in one line
		String[] backLine;
		String[] armLine;
		String[] cardioLine;
		String[] chestLine;
		String[] legLine;
		
		// Shoving all the work out information into the arrays
		for(int i = 0; i < backList.length; i++)
		{
			workout back = new workout();
			backLine = backScan.nextLine().split(";");
			back.workoutSession = backLine[0];
			back.reps = Integer.parseInt(backLine[1]);
			back.descrip = backLine[2];
			backList[i] = back;
		}
		for(int i = 0; i < armList.length; i++)
		{
			workout arm = new workout();
			armLine = armScan.nextLine().split(";");
			arm.workoutSession = armLine[0];
			arm.reps = Integer.parseInt(armLine[1]);
			arm.descrip = armLine[2];
			armList[i] = arm;
		}
		for(int i = 0; i < cardioList.length; i++)
		{
			workout cardio = new workout();
			cardioLine = cardioScan.nextLine().split(";");
			cardio.workoutSession = cardioLine[0];
			cardio.reps = Integer.parseInt(cardioLine[1]);
			cardio.descrip = cardioLine[2];
			cardioList[i] = cardio;
		}
		for(int i = 0; i < chestList.length; i++)
		{
			workout chest = new workout();
			chestLine = chestScan.nextLine().split(";");
			chest.workoutSession = chestLine[0];
			chest.reps = Integer.parseInt(chestLine[1]);
			chest.descrip = chestLine[2];
			chestList[i] = chest;
		}
		for(int i = 0; i < legList.length; i++)
		{
			workout leg = new workout();
			legLine = legScan.nextLine().split(";");
			leg.workoutSession = legLine[0];
			leg.reps = Integer.parseInt(legLine[1]);
			leg.descrip = legLine[2];
			legList[i] = leg;
		}
		System.lineSeparator();
		
		// Printing list contents to see if transition went through
		// Testing only
		System.out.println("List of Back Work Outs:");
		System.out.println("-------------------------");
		for(int i = 0; i < backList.length; i++)
		{
			System.out.println("Workout: " + backList[i].workoutSession + " | Suggested Reps: " + backList[i].reps + " | Decription: " + backList[i].descrip);
		}
		System.out.println();
		System.out.println("List of Arm Work Outs:");
		System.out.println("-------------------------");
		for(int i = 0; i < armList.length; i++)
		{
			System.out.println("Workout: " + armList[i].workoutSession + " | Suggested Reps: " + armList[i].reps + " | Decription: " + armList[i].descrip);
		}
		System.out.println();
		System.out.println("List of Cardio Work Outs:");
		System.out.println("-------------------------");
		for(int i = 0; i < cardioList.length; i++)
		{
			System.out.println("Workout: " + cardioList[i].workoutSession + " | Suggested Reps: " + cardioList[i].reps + " | Decription: " + cardioList[i].descrip);
		}
		System.out.println();
		System.out.println("List of Chest Work Outs:");
		System.out.println("-------------------------");
		for(int i = 0; i < chestList.length; i++)
		{
			System.out.println("Workout: " + chestList[i].workoutSession + " | Suggested Reps: " + chestList[i].reps + " | Decription: " + chestList[i].descrip);
		}
		System.out.println();
		System.out.println("List of Leg Work Outs:");
		System.out.println("-------------------------");
		for(int i = 0; i < legList.length; i++)
		{
			System.out.println("Workout: " + legList[i].workoutSession + " | Suggested Reps: " + legList[i].reps + " | Decription: " + legList[i].descrip);
		}		
	}
}
