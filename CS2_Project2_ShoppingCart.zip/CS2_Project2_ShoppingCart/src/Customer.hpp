/*
 * Customer.hpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#ifndef CUSTOMER_HPP_
#define CUSTOMER_HPP_
#include <string>
#include "Date.hpp"
using namespace std;

class Customer {
public:
	Customer();
	virtual ~Customer();

	void setCustomerNumber(string);
	void setCustomerName(string);
	void setEmail(string);
	void setDateJoined(Date);

	string getCustomerNumber(void);
	string getCustomerName(void);
	string getEmail(void);
	Date getDateJoined(void);

private:
	string customerNumber;
	string customerName;
	string email;
	Date dateJoined;

	void init(void);
};

#endif /* CUSTOMER_HPP_ */
