/*
 * ElectronicItem.hpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#ifndef ELECTRONICITEM_HPP_
#define ELECTRONICITEM_HPP_

#include "OrderItem.hpp"

enum Type {
	TV,
	PS4,
	DVDPlayer,
	Phone,
	Other_Type
};

class ElectronicItem: public OrderItem {
public:
	ElectronicItem();
	virtual ~ElectronicItem();

	void setApplianceType(Type);
	void setApplianceType(int);
	void setWarrantyMonths(int);

	Type getApplianceType(void);
	int getWarrantyMonths(void);

	string whoAmI(void);

private:
	Type applianceType;
	int warrantyMonths;

	void init(void);
};

#endif /* ELECTRONICITEM_HPP_ */
