/*
 * ElectronicItem.cpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#include "ElectronicItem.hpp"

ElectronicItem::ElectronicItem() {
	// TODO Auto-generated constructor stub
	init();
} //default constructor

ElectronicItem::~ElectronicItem() {
	// TODO Auto-generated destructor stub
} //destructor

void ElectronicItem::init(void) {
	applianceType = Other_Type;
	warrantyMonths = 0;
} //init()



//
//member attribute mutator methods
//
void ElectronicItem::setApplianceType(Type aType) {
	applianceType = aType;
} //setApplianceType(Type)

void ElectronicItem::setApplianceType(int typeInt) {
	Type aType;
	switch(typeInt) {
	case 0: aType = TV; break;
	case 1: aType = PS4; break;
	case 2: aType = DVDPlayer; break;
	case 3: aType = Phone; break;
	default: aType = Other_Type;
	} //switch(int)
	applianceType = aType;
} //setApplianceType(int)

void ElectronicItem::setWarrantyMonths(int monthAmount) {
	warrantyMonths = monthAmount;
} //setWarrantyMonths(int)

//
//member attribute accessor methods
//
Type ElectronicItem::getApplianceType(void) {
	return applianceType;
} //getApplianceType()

int ElectronicItem::getWarrantyMonths(void) {
	return warrantyMonths;
} //getWarrantyMonths()

//
string ElectronicItem::whoAmI(void) {
	return "ElectronicItem";
} //whoAmI()
