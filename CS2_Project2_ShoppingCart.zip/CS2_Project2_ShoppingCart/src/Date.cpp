/*
 * Date.cpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#include "Date.hpp"
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

Date::Date() {
	// TODO Auto-generated constructor stub
	init();
} //default constructor

Date::~Date() {
	// TODO Auto-generated destructor stub
} //destructor

void Date::init() {
	year = 0;
	month = 0;
	day = 0;
} //init()



//
//member attribute mutator methods
//
void Date::setYear(int aYear) {
	this->year = aYear;
} //setYear(int)

void Date::setMonth(int aMonth) {
	this->month = aMonth;
} //setMonth(int)

void Date::setDay(int aDay) {
	this->day = aDay;
} //setDay(int)

//
//member attribute accessor methods
//
int Date::getYear(void) {
	return year;
} //getYear()

int Date::getMonth(void) {
	return month;
} //getMonth()

int Date::getDay(void) {
	return day;
} //getDay()

//
//
//
//string Date::printDate(void) {
//	string returnString = (to_string(month) + "/" + to_string(day) + "/" + to_string(year));
//	return returnString;
//} //printDate()
