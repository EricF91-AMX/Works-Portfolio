/*
 * Date.hpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#ifndef DATE_HPP_
#define DATE_HPP_
#include <string>
using namespace std;

class Date {
public:
	Date();
	virtual ~Date();

	void setYear(int);
	void setMonth(int);
	void setDay(int);

	int getYear(void);
	int getMonth(void);
	int getDay(void);

//	string printDate(void);

private:
	int year;
	int month;
	int day;

	void init(void);
};

#endif /* DATE_HPP_ */
