/*
 * Customer.cpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#include "Customer.hpp"
#include "Date.hpp"
#include <iostream>
using namespace std;

Customer::Customer() {
	// TODO Auto-generated constructor stub
	init();
} //default constructor

Customer::~Customer() {
	// TODO Auto-generated destructor stub
} //destructor

void Customer::init(void) {
	customerNumber = "unknown";
	customerName = "unknown";
	email = "unknown";
	dateJoined = Date();
} //init()



//
//member attribute mutator methods
//
void Customer::setCustomerNumber(string aCustomerNumber){
	this->customerNumber = aCustomerNumber;
} //setCustomerNumber(string)

void Customer::setCustomerName(string aCustomerName){
	this->customerName = aCustomerName;
} //setCustomerName(string)

void Customer::setEmail(string anEmail){
	this->email = anEmail;
} //setEmail(string)

void Customer::setDateJoined(Date aDate){
	this->dateJoined = aDate;
} //setDateJoined(Date)

//
//member attribute accessor methods
//
string Customer::getCustomerNumber(void){
	return customerNumber;
} //getCustomerNumber()

string Customer::getCustomerName(void){
	return customerName;
} //getCustomerName()

string Customer::getEmail(void){
	return email;
} //getEmail()

Date Customer::getDateJoined(void){
	return dateJoined;
} //getDateJoined()
