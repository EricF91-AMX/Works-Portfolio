/*
 * MediaItem.cpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#include "MediaItem.hpp"
#include "Date.hpp"

MediaItem::MediaItem() {
	// TODO Auto-generated constructor stub
	init();
} //default constructor

MediaItem::~MediaItem() {
	// TODO Auto-generated destructor stub
} //destructor

void MediaItem::init(void) {
	authorName = "Unknown";
	publicationDate = Date();
	ISBNNumber = "Unknown";
} //init()



//
//member attribute mutator methods
//
void MediaItem::setAuthorName(string anAuthorName) {
	this->authorName = anAuthorName;
} //setAuthorName(string)

void MediaItem::setPublicationDate(Date aDate) {
	this->publicationDate = aDate;
} //setPublicationDate(Date)

void MediaItem::setISBNNumber(string anISBNNumber) {
	this->ISBNNumber = anISBNNumber;
} //setISBNNumber(string)

//
//member attribute accessor methods
//
string MediaItem::getAuthorName(void) {
	return authorName;
} //getAuthorName()

Date MediaItem::getPublicationDate(void) {
	return publicationDate;
} //getPublicationDate()

string MediaItem::getISBNNumber(void) {
	return ISBNNumber;
} //getISBNNumber()

//
string MediaItem::whoAmI(void) {
	return "MediaItem";
} //whoAmI()
