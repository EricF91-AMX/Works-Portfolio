/*
 * FoodItem.cpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#include "FoodItem.hpp"
#include "Date.hpp"

FoodItem::FoodItem() {
	// TODO Auto-generated constructor stub
	init();
} //default constructor

FoodItem::~FoodItem() {
	// TODO Auto-generated destructor stub
} //destructor

void FoodItem::init(void) {
	expirationDate = Date();
	calories = 0;
	fat = 0;
} //init()



//
//member attribute mutator methods
//
void FoodItem::setExpirationDate(Date aDate) {
	this->expirationDate = aDate;
} //setExpirationDate(Date)

void FoodItem::setCalories(int numCalories) {
	this->calories = numCalories;
} //setCalories(int)

void FoodItem::setFat(int numFat) {
	this->fat = numFat;
} //setFat(int)

//
//member attribute accessor methods
//
Date FoodItem::getExpirationDate(void) {
	return expirationDate;
} //getExpirationDate()

int FoodItem::getCalories(void) {
	return calories;
} //getCalories()

int FoodItem::getFat(void) {
	return fat;
} //getFat()

//
string FoodItem::whoAmI(void) {
	return "FoodItem";
} //whoAmI()
