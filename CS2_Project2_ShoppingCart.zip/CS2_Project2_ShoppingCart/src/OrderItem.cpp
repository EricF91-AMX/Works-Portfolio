/*
 * OrderItem.cpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#include "OrderItem.hpp"

OrderItem::OrderItem() {
	// TODO Auto-generated constructor stub
	init();
} //default constructor

OrderItem::~OrderItem() {
	// TODO Auto-generated destructor stub
} //destructor

void OrderItem::init(void) {
	orderNumber = "Unknown";
	itemNumber = "Unknown";
	itemDescription = "Unknown";
	quantity = 0;
	customerCost = 0.00;
	vendorCost = 0.00;
	taxExempt = false;
} //init()



//
//member attribute mutator methods
//
void OrderItem::setOrderNumber(string anOrderNumber) {
	this->orderNumber = anOrderNumber;
} //setOrderNumber(string)

void OrderItem::setItemNumber(string anItemNumber) {
	this->itemNumber = anItemNumber;
} //setItemNumber(string)

void OrderItem::setItemDescription(string anItemDescription) {
	this->itemDescription = anItemDescription;
} //setItemDescription(string)

void OrderItem::setQuantity(int aQuantity) {
	this->quantity = aQuantity;
} //setQuantity(int)

void OrderItem::setCustomerCost(double aCustomerCost) {
	this->customerCost = aCustomerCost;
} //setCustomerCost(double)

void OrderItem::setVendorCost(double aVendorCost) {
	this->vendorCost = aVendorCost;
} //setVendorCost(double)

void OrderItem::setTaxExempt(string isTaxExempt) {
	bool exemptStatus = false;
	if(isTaxExempt == "Y") {
		exemptStatus = true;
	} //if
	else if(isTaxExempt == "N") {
		exemptStatus = false;
	} //else if
	this->taxExempt = exemptStatus;
} //setTaxExempt(bool)

//
//member attribute accessor methods
//
string OrderItem::getOrderNumber(void) {
	return orderNumber;
} //getOrderNumber()

string OrderItem::getItemNumber(void) {
	return itemNumber;
} //getItemNumber()

string OrderItem::getItemDescription(void) {
	return itemDescription;
} //getItemDescription()

int OrderItem::getQuantity(void) {
	return quantity;
} //getQuantity()

double OrderItem::getCustomerCost(void) {
	return customerCost;
} //getCustomerCost()

double OrderItem::getVendorCost(void) {
	return vendorCost;
} //getVenderCost()

bool OrderItem::getTaxExempt(void) {
	return taxExempt;
} //getTaxExempt()

//
//
//
string OrderItem::whoAmI(void) {
	return "OrderItem";
} //whoAmI()
