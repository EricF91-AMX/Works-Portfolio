//*****************

//Project Name: Chapter 15 - Project #2: The Big One!

//Project Description: Shopping cart

//Project Author: Fong, Eric

//Is this an extra credit Project:  No

//Date completed: 11/15/2017

//Operating system used: Windows

//IDE Used:  Eclipse



//*****************
// Main File Name        : CS2_Project2_ShoppingCart.cpp

#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>
#include "Customer.hpp"
#include "Order.hpp"
#include "Date.hpp"
using namespace std;

int main(int argc, const char* argv[]) {
	//declare file streaming variable
	fstream cartFile;

	//declare variables for reading info from files
	string readingString1;
	string readingString2;
	int readingInt;

	//create a vector of Customer pointers
	vector<Customer*> theCustomers;

	//read customer info from file
	//open the file to input from
	cartFile.open("CustomerFile.txt", ios::in);
	Customer* customerPtr;
	Date* datePtr;
	//TODO Remove file streaming error messages and exits
	if(!cartFile) {
		cout << "Could not open CustomerFile.txt for reading." << endl;
		exit(1);
	} //if
	//loop for reading cartFile contents into CustomerVector
	while(!cartFile.eof()) {
		customerPtr = new Customer();
		datePtr = new Date();
		cartFile >> readingString1;		//'>>' streaming operator used for
										//reading from file, like 'cin >>'
		customerPtr->setCustomerNumber(readingString1);
		cartFile >> readingString1;
		customerPtr->setCustomerName(readingString1);
		cartFile >> readingString1;
		customerPtr->setEmail(readingString1);
		cartFile >> readingInt;
		datePtr->setYear(readingInt);
		cartFile >> readingInt;
		datePtr->setMonth(readingInt);
		cartFile >> readingInt;
		datePtr->setDay(readingInt);
		customerPtr->setDateJoined(*datePtr);

		theCustomers.push_back(customerPtr);
	} //while
	//close CustomerFile.txt
	cartFile.close();	//files closed to protect the data
	delete customerPtr;

	//create a vector of Order pointers
	vector<Order*> theOrders;

	//read orders from OrderFile.txt
	//open the file to input from
	cartFile.open("OrderFile.txt", ios::in);
	Order* orderPtr;
	if(!cartFile) {
		cout << "Could not open OrderFile.txt for reading." << endl;
		exit(1);
	} //if
	//loop for reading cartFile contents into CustomerVector
	while(!cartFile.eof()) {
		datePtr = new Date();
		cartFile >> readingString1;
		cartFile >> readingInt;
		datePtr->setYear(readingInt);
		cartFile >> readingInt;
		datePtr->setMonth(readingInt);
		cartFile >> readingInt;
		datePtr->setDay(readingInt);
		cartFile >> readingString2;
//		orderPtr = new Order();
		orderPtr = new Order("FoodItems.txt", "MediaItems.txt",
				"ElectronicItems.txt", theCustomers, readingString1,
				datePtr, readingString2);
		orderPtr->setOrderNumber(readingString1);
		orderPtr->setOrderDate(*datePtr);
		orderPtr->setOrderCustomer(readingString2, theCustomers);

		theOrders.push_back(orderPtr);
	} //while
	//close CustomerFile.txt
	cartFile.close();	//files closed to protect the data
	delete orderPtr;
	delete datePtr;

//	//print each order
//	cout << "Order Report" << endl;
//	cout << "==============================" << endl;
//	for(unsigned int i = 0; i < theOrders.size(); i++) {
//		cout << setw(15) << "Order ID" << setw(15) << "Customer ID"
//				<< setw(12) << "Order Date" << setw(18) << "Customer" << endl;
//		cout << setw(15) << theOrders[i]->getOrderNumber() << setw(15)
//				<< theOrders[i]->getOrderCustomer()->getCustomerNumber()
//				<< setw(12) << theOrders[i]->getOrderDate().getMonth() << "/"
//				<< theOrders[i]->getOrderDate().getDay() << "/"
//				<< theOrders[i]->getOrderDate().getYear()
//				<< setw(18) << theOrders[i]->getOrderCustomer()->getCustomerName()
//				<< endl;
//		cout << "=============================" << endl;
//
//		// orderID  customerID  orderDate  customerName
//		//---
//		//foodItemsOrdered:  itemNumber  itemDescription  calories  cost
//		//--
//		//mediaItemsOrdered:  itemNumber  itemDescription  ISBN  cost
//		//--
//		//electronicItemsOrdered:  itemNumber  itemDescription  warranty  cost
//		//totalOfOrder:
//		//===
//		//
//	} //for


	cout << "Program ending, have a nice day." << endl;
	return 0;
}



/* cartFileInput main() code
	//declare file streaming variable
	fstream cartFile;

	//create a vector of Customer pointers
	vector<Customer*> CustomerVector;

	//open the file to input from
	cartFile.open("CustomerInventory.txt", ios::in);

	//display error message and end program if cartFile fails to open
	if(!cartFile) {
		cout << "Customer file did not open, program ending." << endl;
			//if cartFile does not exist, then cartFile is NULL
		return 999;
	} //if
	else {
		cout << "Customer file opened, great!" << endl;
	} //else

	Customer* customerPtr;
	//loop for reading cartFile contents into CustomerVector
	while(!cartFile.eof()) {
		customerPtr = new Customer();
		cartFile >> customerPtr->name;		//'>>' streaming operator used for reading from file, like 'cin >>'
		cartFile >> customerPtr->price;
		cartFile >> customerPtr->calories;
		cartFile >> customerPtr->inStock;

		CustomerVector.push_back(customerPtr);
	} //while
	cartFile.close();	//files closed to protect the data
	delete customerPtr;

	//set up formatted output
	cout << "Customer Menu Report" << endl;
	cout << "=================" << endl << endl;
	cout << setw(16) << left << "Name" << setw(12) << right << "Price" << setw(12) << "Calories" << setw(10) << "In Stock" << endl;
	cout << setw(16) << left << "----" << setw(12) << right << "-----" << setw(12) << "--------" << setw(10) << "--------" << endl;

	//loop for printing cartFile contents in proper format
	for(unsigned int i = 0; i < CustomerVector.size(); i++) {
		cout << setw(16) << left << CustomerVector[i]->name << setw(12) << right << CustomerVector[i]->price << setw(12) << right << CustomerVector[i]->calories << setw(10) << right << CustomerVector[i]->inStock << endl;
	} //for

	//delete CustomerVector contents
	for(unsigned int i = 0; i < CustomerVector.size(); i++) {
		delete CustomerVector[i];
	} //for
*/

/* How Prof is going to test proj functionality:
 * in command line
 * Test#1: program name alone
 * Test#2: program name w/ one orderNumber
 * Test#3: program name w/ two orderNumbers
 * Test#4: program name w/ one orderNumber that doesn't exist
 */
