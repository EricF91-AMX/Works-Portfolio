/*
 * MediaItem.hpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#ifndef MEDIAITEM_HPP_
#define MEDIAITEM_HPP_

#include <string>
#include "OrderItem.hpp"
#include "Date.hpp"
using namespace std;

class MediaItem: public OrderItem {
public:
	MediaItem();
	virtual ~MediaItem();

	void setAuthorName(string);
	void setPublicationDate(Date);
	void setISBNNumber(string);

	string getAuthorName(void);
	Date getPublicationDate(void);
	string getISBNNumber(void);

	string whoAmI(void);

private:
	string authorName;
	Date publicationDate;
	string ISBNNumber;

	void init(void);
};

#endif /* MEDIAITEM_HPP_ */
