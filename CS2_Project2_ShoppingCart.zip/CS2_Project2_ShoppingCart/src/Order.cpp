/*
 * Order.cpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#include "Order.hpp"
#include "Date.hpp"
#include "Customer.hpp"
#include "FoodItem.hpp"
#include "MediaItem.hpp"
#include "ElectronicItem.hpp"
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

Order::Order() {
	// TODO Auto-generated constructor stub
	init();
} //default constructor

Order::Order(const char foodItemFile[], const char mediaItemFile[], const char
		electronicItemFile[], vector<Customer*> customerVector, string orderNum,
		Date* odrDate, string orderCust) {
	init();
	this->setOrderNumber(orderNum);
	this->setOrderDate(*odrDate);
	this->setOrderCustomer(orderCust, customerVector);

	readFoodItems(foodItemFile, orderNum);
	readMediaItems(mediaItemFile, orderNum);
	readElectronicItems(electronicItemFile, orderNum);
} //constructor w/ 3 string args

Order::~Order() {
	// TODO Auto-generated destructor stub
} //destructor

void Order::init(void) {
	orderNumber = "Unknown";
	orderDate = Date();
	orderCustomer = new Customer();
} //init()



//
//member attribute mutator methods
//
void Order::setOrderNumber(string anOrderNumber) {
	this->orderNumber = anOrderNumber;
} //setOrderNumber(string)

void Order::setOrderDate(Date aDate) {
	this->orderDate = aDate;
} //setOrderDate(Date)

void Order::setOrderCustomer(string aCustomerID, vector<Customer*> customerVector) {
	Customer* theCustomer;
	for(unsigned int i = 0; i < customerVector.size(); i++) {
		if(aCustomerID == customerVector[i]->getCustomerNumber()) {
			theCustomer = customerVector[i];
		} //if
	} //for
	this->orderCustomer = theCustomer;
} //setOrderCustomer(string, vector<Customer*>)

void Order::addOrderItem(OrderItem anOrderItem) {
	this->ItemsInOrder.push_back(&anOrderItem);
} //addOrderItem(OrderItem)

//
//member attribute accessor methods
//
string Order::getOrderNumber(void) {
	return orderNumber;
} //getOrderNumber()

Date Order::getOrderDate(void) {
	return orderDate;
} //getOrderDate()

Customer* Order::getOrderCustomer(void) {
	return orderCustomer;
} //getOrderCustomer

//
//
//
void Order::readFoodItems(const char fileName[], string orderNum) {
	//declare file streaming variable
	fstream cartFile;

	//declare variables for reading info from files
	string readingString;
	Date readingDate;
	int readingInt;
	double readingDouble;

	//read customer info from file
	//open the file to input from
	cartFile.open(fileName, ios::in);
	FoodItem* foodPtr;
	Date* datePtr;
	if(!cartFile) {
		cout << "Error, could not open MediaItems.txt for reading." << endl;
		exit(1);
	}
	//loop for reading cartFile contents into CustomerVector
	while(!cartFile.eof()) {
		foodPtr = new FoodItem();
		datePtr = new Date();
		cartFile >> readingString;		//'>>' streaming operator used for reading from file, like 'cin >>'
		foodPtr->setOrderNumber(readingString);
		cartFile >> readingString;
		foodPtr->setItemNumber(readingString);
		cartFile >> readingString;
		foodPtr->setItemDescription(readingString);
		cartFile >> readingInt;
		foodPtr->setQuantity(readingInt);
		cartFile >> readingDouble;
		foodPtr->setCustomerCost(readingDouble);
		cartFile >> readingDouble;
		foodPtr->setVendorCost(readingDouble);
		cartFile >> readingString;
		foodPtr->setTaxExempt(readingString);
		cartFile >> readingInt;
		datePtr->setYear(readingInt);
		cartFile >> readingInt;
		datePtr->setMonth(readingInt);
		cartFile >> readingInt;
		datePtr->setDay(readingInt);
		foodPtr->setExpirationDate(*datePtr);
		cartFile >> readingInt;
		foodPtr->setCalories(readingInt);
		cartFile >> readingInt;
		foodPtr->setFat(readingInt);

		if(foodPtr->getOrderNumber() == orderNum) {
			ItemsInOrder.push_back(foodPtr);
		} //if
	} //while
	//close CustomerFile.txt
	cartFile.close();	//files closed to protect the data
	delete foodPtr;
	delete datePtr;
} //readFoodItems(string)

void Order::readMediaItems(const char fileName[], string orderNum) {
	//declare file streaming variable
	fstream cartFile;

	//declare variables for reading info from files
	string readingString;
	Date readingDate;
	int readingInt;
	double readingDouble;

	//read customer info from file
	//open the file to input from
	cartFile.open(fileName, ios::in);
	MediaItem* mediaPtr;
	Date* datePtr;
	if(!cartFile) {
		cout << "Error, could not open MediaItems.txt for reading." << endl;
		exit(1);
	}
	//loop for reading cartFile contents into CustomerVector
	while(!cartFile.eof()) {
		mediaPtr = new MediaItem();
		datePtr = new Date();
		cartFile >> readingString;		//'>>' streaming operator used for reading from file, like 'cin >>'
		mediaPtr->setOrderNumber(readingString);
		cartFile >> readingString;
		mediaPtr->setItemNumber(readingString);
		cartFile >> readingString;
		mediaPtr->setItemDescription(readingString);
		cartFile >> readingInt;
		mediaPtr->setQuantity(readingInt);
		cartFile >> readingDouble;
		mediaPtr->setCustomerCost(readingDouble);
		cartFile >> readingDouble;
		mediaPtr->setVendorCost(readingDouble);
		cartFile >> readingString;
		mediaPtr->setTaxExempt(readingString);
		cartFile >> readingInt;
		datePtr->setYear(readingInt);
		cartFile >> readingInt;
		datePtr->setMonth(readingInt);
		cartFile >> readingInt;
		datePtr->setDay(readingInt);
		mediaPtr->setPublicationDate(*datePtr);
		cartFile >> readingString;
		mediaPtr->setAuthorName(readingString);
		cartFile >> readingString;
		mediaPtr->setISBNNumber(readingString);

		if(mediaPtr->getOrderNumber() == orderNum) {
			ItemsInOrder.push_back(mediaPtr);
		} //if
	} //while
	//close CustomerFile.txt
	cartFile.close();	//files closed to protect the data
	delete mediaPtr;
	delete datePtr;
} //readMediaItems(string)

void Order::readElectronicItems(const char fileName[], string orderNum) {
	//declare file streaming variable
	fstream cartFile;

	//declare variables for reading info from files
	string readingString;
	Date readingDate;
	int readingInt;
	double readingDouble;

	//read customer info from file
	//open the file to input from
	cartFile.open(fileName, ios::in);
	ElectronicItem* electronicPtr;
	if(!cartFile) {
		cout << "Error, could not open MediaItems.txt for reading." << endl;
		exit(1);
	}
	//loop for reading cartFile contents into CustomerVector
	while(!cartFile.eof()) {
		electronicPtr = new ElectronicItem();
		cartFile >> readingString;		//'>>' streaming operator used for reading from file, like 'cin >>'
		electronicPtr->setOrderNumber(readingString);
		cartFile >> readingString;
		electronicPtr->setItemNumber(readingString);
		cartFile >> readingString;
		electronicPtr->setItemDescription(readingString);
		cartFile >> readingInt;
		electronicPtr->setQuantity(readingInt);
		cartFile >> readingDouble;
		electronicPtr->setCustomerCost(readingDouble);
		cartFile >> readingDouble;
		electronicPtr->setVendorCost(readingDouble);
		cartFile >> readingString;
		electronicPtr->setTaxExempt(readingString);
		cartFile >> readingInt;
		electronicPtr->setApplianceType(readingInt);
		cartFile >> readingInt;
		electronicPtr->setWarrantyMonths(readingInt);

		if(electronicPtr->getOrderNumber() == orderNum) {
			ItemsInOrder.push_back(electronicPtr);
		} //if
	} //while
	//close CustomerFile.txt
	cartFile.close();	//files closed to protect the data
	delete electronicPtr;
} //readElectronicItems(string)

double Order::getTotalOfOrder(void) {
	double returnValue = 0;

	for (unsigned int i = 0; i < ItemsInOrder.size(); i++) {
		returnValue += ItemsInOrder[i]->getCustomerCost() * ItemsInOrder[i]->getQuantity();
	} //for

	return returnValue;
} //getTotalOfOrder()
