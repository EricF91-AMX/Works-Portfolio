/*
 * Order.hpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#ifndef ORDER_HPP_
#define ORDER_HPP_
#include <string>
#include <vector>
#include "Date.hpp"
#include "OrderItem.hpp"
//#include "FoodItem.hpp"
//#include "MediaItem.hpp"
//#include "ElectronicItem.hpp"
#include "Customer.hpp"
using namespace std;

class Order {
public:
	Order();
	Order(const char foodItemFile[], const char mediaItemFile[], const char
			electronicItemFile[], vector<Customer*>, string OrdNum, Date*
			ordDate, string ordCust);
	virtual ~Order();

	void setOrderNumber(string);
	void setOrderDate(Date);
	void setOrderCustomer(string, vector<Customer*>);
	void addOrderItem(OrderItem);

	string getOrderNumber(void);
	Date getOrderDate(void);
	Customer* getOrderCustomer(void);

	void readFoodItems(const char fileName[], string orderNum);
	void readMediaItems(const char fileName[], string orderNum);
	void readElectronicItems(const char fileName[], string orderNum);
	double getTotalOfOrder(void);

private:
	string orderNumber;
	Date orderDate;
	vector<OrderItem*> ItemsInOrder;
	Customer* orderCustomer;

	void init(void);
};

#endif /* ORDER_HPP_ */
