/*
 * OrderItem.hpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#ifndef ORDERITEM_HPP_
#define ORDERITEM_HPP_
#include <string>
using namespace std;

class OrderItem {
public:
	OrderItem();
	virtual ~OrderItem();

	void setOrderNumber(string);
	void setItemNumber(string);
	void setItemDescription(string);
	void setQuantity(int);
	void setCustomerCost(double);
	void setVendorCost(double);
	void setTaxExempt(string);

	string getOrderNumber(void);
	string getItemNumber(void);
	string getItemDescription(void);
	int getQuantity(void);
	double getCustomerCost(void);
	double getVendorCost(void);
	bool getTaxExempt(void);

	virtual string whoAmI(void);

private:
	string orderNumber;
	string itemNumber;
	string itemDescription;
	int quantity;
	double customerCost;
	double vendorCost;
	bool taxExempt;

	void init(void);
};

#endif /* ORDERITEM_HPP_ */
