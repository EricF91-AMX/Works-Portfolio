/*
 * FoodItem.hpp
 *
 *  Created on: Oct 26, 2017
 *      Author: student
 */

#ifndef FOODITEM_HPP_
#define FOODITEM_HPP_

#include <string>
#include "OrderItem.hpp"
#include "Date.hpp"
using namespace std;

class FoodItem: public OrderItem {
public:
	FoodItem();
	virtual ~FoodItem();

	void setExpirationDate(Date);
	void setCalories(int);
	void setFat(int);

	Date getExpirationDate(void);
	int getCalories(void);
	int getFat(void);

	string whoAmI(void);

private:
	Date expirationDate;
	int calories;
	int fat;

	void init(void);
};

#endif /* FOODITEM_HPP_ */
